package SV;

import java.util.Scanner;
public class Q10 {
	public static void main(String[] args) {
		Scanner sv=new Scanner(System.in);
		System.out.println("Enter temperature in fahrenheit:");
		double a=sv.nextDouble();
		Q10 n=new Q10();
		double res=n.celsius(a);
		System.out.print("Temperature in celsius is:"+res);
	}
	double celsius(double a) {
		double c=((a-32)*5)/9;
		return c;
	}
}
