package SV;

import java.util.Scanner;
public class Q345 {
	public static void main(String[] args) {
		Scanner sv=new Scanner(System.in);
		System.out.println("Enter the side of square:");
		int a=sv.nextInt();
		System.out.println("Enter the sides of rectangle:");
		int l=sv.nextInt();
		int b=sv.nextInt();
		System.out.println("Enter the radius of circle:");
		double r=sv.nextDouble();
		Q345 n=new Q345();
		int res=n.square(a);
		System.out.println("Area of square:"+res);
		int sol=n.rectangle(l,b);
		System.out.println("Area of rectangle:"+sol);
		Double ans=n.circle(r);
		System.out.println("Area of circle:"+ans);
	}
	int square(int a) {
		return a*a;
	}
	int rectangle(int l,int b) {
		return l*b;
	}
	double circle(double r) {
		double c= 3.14*r*r;
		return c;
	}
}
