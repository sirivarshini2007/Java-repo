package SV;

import java.util.Scanner;
public class Q2 {
	public static void main(String[] args) {
		Scanner gs=new Scanner(System.in);
		System.out.println("Enter the values of a,b,c:");
		int a=gs.nextInt();
		int b=gs.nextInt();
		int c=gs.nextInt();
		Q2 cx=new Q2();
		int ans=cx.add(a,b,c);
		System.out.print("Addition of three numbers: "+ans);
	}
	int add(int a,int b,int c) {
		int d=a+b+c;
		return d;
	}
}
