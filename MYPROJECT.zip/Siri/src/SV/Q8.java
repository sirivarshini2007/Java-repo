package SV;

import java.util.Scanner;
public class Q8 {
	public static void main(String[] args) {
		Scanner sv=new Scanner(System.in);
		System.out.println("Enter number of hours worked in a week,rate per hour,number of weeks in a month:");
		int a=sv.nextInt();//Number of hours worked in a week//
		int b=sv.nextInt();//rate per hour//
		int c=sv.nextInt();//number of weeks in a month//
		Q8 n=new Q8();
		int res=n.monthlypay(a,b,c);
		System.out.println("monthly-pay:"+res);
	}
	int monthlypay(int a,int b,int c) {
		int d=a*b*c;
		return d;
	}
}
