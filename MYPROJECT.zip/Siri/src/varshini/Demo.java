package varshini;

public class siri {
	public static void main(String[] args) {
		Cat cat =new Cat();
		cat.speak(1);
	}
}
class Animal{
	void speak(String s) {
		System.out.println("Hello this is animal Speaking"+s);
	}
}
class Cat extends Animal{
	void speak(int i) {
		System.out.println("Meow");
	}
}
