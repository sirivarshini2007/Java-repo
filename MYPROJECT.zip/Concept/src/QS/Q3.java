package QS;

public class Q3 {
	public static void main(String[] args) {
		Dev3 s=new Dev3();
		s.deposit();
		s.account();
	}
}
interface Bank{
	void loan();
	void balance();
	void account();
	void deposit();
}
abstract class Dev1 implements Bank{
	public void deposit() {
		System.out.println("Deposit is:"+1000);
	}
}
abstract class Dev2 extends Dev1{
	public void account() {
		System.out.println("Your account has:"+5000);
	}
}
class Dev3 extends Dev2{
	public void loan() {}
	public void balance() {}
}