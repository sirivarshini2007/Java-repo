package example;

import java.util.Arrays;
public class Q6 {
	public static void main(String[] args) {
		int [] arr1= {1,2,3};
		int [] arr2= {4,5,6};
		int length=arr1.length+arr2.length;
		int [] result=new int[length];
		int pos=0;
		for(int x:arr1) {
			result[pos]=x;
			pos++;
		}
		for(int y:arr2) {
			result[pos]=y;
			pos++;
		}
		System.out.println(Arrays.toString(result));
	}
}
