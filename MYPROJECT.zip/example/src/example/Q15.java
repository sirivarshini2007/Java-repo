package example;

public class Q15 {
	public static void main(String[] args) {
		A [] arr=new A [3];
		arr[0]=new A("Siri",101);
		arr[1]=new A("Varshi",102);
		arr[2]=new A("Harshi",103);
		for(A x:arr) {
			x.display();
		}
	}
}
class A{
	String name;
	int roll;
	A(String name,int roll){
		this.name=name;
		this.roll=roll;
	}
	void display() {
		System.out.println("Name is:"+name+"roll"+roll);
	}
}
