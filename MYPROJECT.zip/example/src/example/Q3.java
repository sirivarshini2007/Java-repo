package example;

import java.util.Scanner;
public class Q3 {
	public static void main(String[] args) {
		String temp;
		int count;
		Scanner sv=new Scanner(System.in);
		System.out.println("Enter the count:");
		count=sv.nextInt();
		String [] arr=new String [count];
		Scanner sv1=new Scanner(System.in);
		System.out.println("Enter the strings one by one:");
		for(int i=0;i<count;i++) {
			arr[i]=sv1.nextLine();
		}
		for(int i=0;i<count;i++) {
			for(int j=i+1;j<count;j++) {
				if (arr[i].compareTo(arr[j])>0){
					temp=arr[i];
					arr[i]=arr[j];
					arr[j]=temp;
				}
			}
		}
		for(int i=0;i<=count-1;i++) {
			System.out.println(arr[i]);
		}
	}
}
