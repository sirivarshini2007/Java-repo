package example;

public class Q10 {
	public static void main(String[] args) {
		Instance s=new Instance();
		System.out.println(s.name);
		System.out.println(s.i);
		System.out.println(s.I);
	}
}
class Instance{
	public String name;
	public int i;
	public Integer I;
	public Instance() {
		this.name="Siri";
	}
}