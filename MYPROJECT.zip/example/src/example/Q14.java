package example;

public class Q14 {
	public class StaticVariable{
		public static String name="Siri";
	}
	public static void main(String [] args) {
		System.out.println("Geek varaisble name is:"+StaticVariable.name);
	}
}
