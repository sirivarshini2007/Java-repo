package example;

public class Q8 {
	public static void main(String[] args) {
	Siri s=new Siri();
	s.m();
	n();
	s.l();
	}
}
class Siri{
	static int a=10;
	static int b=20;
	static int c=30;
	Siri(){
		a=40;
	}
	static {
		b=50;
	}
	void m() {
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
	}
	static void n() {
		c=60;
	}
	void l() {
		c=70;
	}
}
