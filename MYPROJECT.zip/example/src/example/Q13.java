package example;

public class Q13 {
	{
		System.out.println("Inside the instance block 1:");
	}
	static {
		System.out.println("Ststic block 2");
	}
	public static void main(String [] args) {
		B b=new B("amrita");
		b.add();
	}
	static {
		System.out.println("Ststic block 1");
	}
}
class B{
	int x=40;
	{
		int w=10;
		System.out.println(x);
		System.out.println(w+"INSTANCE");
	}
	B(String sd){
		System.out.println("inside constructor"+sd);
	}
	void add() {
		int a,b,c;
		a=10;
		b=20;
		c=30;
		int d=a+b+c;
		System.out.println(d);
	}
}
