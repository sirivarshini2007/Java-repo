package example;

public class Q9 {
	public static void main(String[] args) {
		System.out.println("Hello first line in main:");
		Q9 e1=new Q9();
		System.out.println("Hello second line in main:");
		Q9 e2=new Q9("Amrita",101);
	}
	Q9(){
		System.out.println("hello first line in constructor");
	}
	Q9(String name,int roll){
		System.out.println("Name:"+name+"roll"+roll);
	}
	static void display() {
		System.out.println("Hello first line in display");
	}
	{
		System.out.println("Hello first line in instane block");
	}
	static {
		System.out.println("Hello first line in static block");
	}
}
