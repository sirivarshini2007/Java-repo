package you;
import java.util.Scanner;
public class Main3 {
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		Product [] obj=new Product [5];
		for(int i=0;i<5;i++) {
			System.out.println("Enter product:"+i+1);
			System.out.println("Enter laptop code:");
			int code=s.nextInt();
			System.out.println("Enter laptop name:");
			String name=s.next();
			obj[i]=new Product();
			obj[i].set(code,name);
		}
		for(int i=0;i<5;i++) {
			obj[i].get();
		}
	}
}
class Product{
	private int code;
	private String name;
	public void set(int l,String n) {
		code=l;
		name=n;
	}
	public void get() {
		System.out.println("Code :"+code+" Name:"+name);
	}
}
