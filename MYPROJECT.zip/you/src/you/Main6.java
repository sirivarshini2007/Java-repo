package you;
import java.util.Scanner;
public class Main6 {
	public static void main(String [] args) {
		Scanner s=new Scanner(System.in);
		Car [] arr=new Car[5];
		for(int i=0;i<5;i++) {
			System.out.println("Enter car name:");
			String name=s.next();
			System.out.println("Enter car model:");
			String model=s.next();
			System.out.println("Enter price:");
			int price=s.nextInt();
			arr[i]=new Car();
			arr[i].set(name,model,price);
		}
		System.out.println("1.Specify model: ");
		System.out.println("2.Specify price:");
		System.out.println("Enter any one from the above choice:");
		int choice=s.nextInt();
		switch(choice) {
		case 1:
			System.out.println("Enter model");
			String modelname=s.next();
			for(Car e:arr) {
				if(e.model==modelname) {
					e.display();
				}
			}
			break;
		case 2:
			System.out.println("Enter price :");
			int cost=s.nextInt();
			for(Car e:arr) {
				if(e.price>=cost) {
					e.display();
				}
			}
			break;
		default:
			System.out.println("Invalid choice:");
			break;
		}
		System.out.println("Thankyou for visiting showroom");
	}
}
class Car{
	String name;
	String model;
	int price;
	public void set(String l,String m,int n) {
		name=l;
		model=m;
		price=n;
	}
	public void display() {
		System.out.println("Name:"+name+" Model:"+model+" Price:"+price);
	}
}
