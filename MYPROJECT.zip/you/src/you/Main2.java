package you;
import java.util.Scanner;
public class Main2 {
	public static void main(String[] args) {
		Student[] st=new Student[5];
		Scanner s=new Scanner(System.in);
		for(int i=0;i<5;i++) {
			System.out.println("student"+i+1);
			System.out.println("Enter name:");
			String name=s.next();
			System.out.println("Enter roll number:");
			int roll=s.nextInt();
			System.out.println("Enter marks:");
			int marks=s.nextInt();
			st[i]=new Student();
			st[i].set(name,roll,marks);
		}
		for(int i=0;i<5;i++) {
			st[i].print();
		}
	}
}
class Student{
	private String name;
	private int  roll;
	private int marks;
	public void set(String l,int m,int n) {
		name=l;
		roll=m;
		marks=n;
	}
	public void print() {
		System.out.println("Name:"+name+"Roll number:"+roll+"Marks:"+marks);
	}
}