package you;
import java.util.Scanner;
public class Main5 {
	public static void main(String[] args) {
		Scanner sv=new Scanner(System.in);
		System.out.println("Enter your name,pinnumber,balance:");
		String name=sv.next();
		int pinnumber=sv.nextInt();
		int balance=sv.nextInt();
		Bank op=new Bank(name,pinnumber,balance);
		System.out.println("Welcome to the bank:");
		System.out.println("Choose an option from below:");
		System.out.println("1.Withdrawal");
		System.out.println("2.Deposit:");
		System.out.println("3.change PIN Number");
		System.out.println("4.check balance:");
		int  option=sv.nextInt();
		switch(option) {
		case 1:
			System.out.println("Enter amount to be withdrawn:");
			int amount=sv.nextInt();
			if(amount>op.balance) {
				op.insuff();
				System.out.println("your balance is:"+op.balance());
			}
			else {
				op.withdrawal(amount);
				System.out.println("your balance is:"+op.balance());
			}
			break;
		case 2:
			System.out.println("Enter amount to be deposited:");
			int cash=sv.nextInt();
			op.deposit(cash);
			System.out.println("your balance is:"+op.balance());
			break;
		case 3:
			System.out.println("Enter new pin:");
			int pin=sv.nextInt();
			if(pin==op.getpin()) {
				System.out.println("It is the same pin");
			}
			else {
				op.changepin(pin);
			}
			break;
		case 4:
			System.out.println("Your balance is:"+op.balance);
			break;
		default:
			System.out.println("Invalid choice");
			break;
		}
		System.out.println("Thankyou for visiting the bank");
	}
}
class Bank{
	String name;
	int pinnumber;
	int balance;
	public  Bank(String name,int pinnumber,int balance) {
		this.name=name;
		this.pinnumber=pinnumber;
		this.balance=balance;
	}
	public void insuff() {
		System.out.println("Insufficient funds");
	}
	public void withdrawal(int amount) {
		balance-=amount;
	}
	public void deposit(int cash) {
		balance+=cash;
	}
	public void changepin(int pin) {
		System.out.println("New password:"+pin);
	}
	public int balance() {
		return balance;
	}
	public int getpin() {
		return pinnumber;
	}
}
