package you;
import java.util.Scanner;
public class Main11 {
	public static void main(String[] args) {
		Scanner sv=new Scanner(System.in);
		System.out.println("Enter x1,y1,x2,y2:");
		int x1=sv.nextInt();
		int y1=sv.nextInt();
		int x2=sv.nextInt();
		int y2=sv.nextInt();
		Point n=new Point(x1,y1,x2,y2);
		System.out.println("Thde distance between two points is:"+n.distance());
	}
}
class Point{
	private int x1;
	private int y1;
	private int x2;
	private int y2;
	public Point(int x1,int y1,int x2,int y2) {
		this.x1=x1;
		this.y1=y1;
		this.x2=x2;
		this.y2=y2;
	}
	public double distance() {
		double d=Math.pow(x2-x1, 2)+Math.pow(y2-y1,2);
		return Math.pow(d, 0.5);
	}
}
