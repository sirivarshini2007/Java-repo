package you;
import java.util.Scanner;
public class Main10 {
	public static void main(String[] args) {
		System.out.println("Enter the values of dept, book name, and code for the first book:");
		Scanner sv = new Scanner(System.in);
        String dept1 = sv.nextLine();  
        String name1 = sv.nextLine();
        int code1 = sv.nextInt();
        sv.nextLine();
		LibraryTest L1=new LibraryTest(dept1,name1,code1);
		System.out.println("Enter the values of dept, book name, and code for the second book:");
        String dept2 = sv.nextLine();  
        String name2 = sv.nextLine();
        int code2 = sv.nextInt();
        sv.nextLine();
		LibraryTest L2=new LibraryTest(dept2,name2,code2);
		L1.getData();
	    L2.getData();
		L1.display();
		L2.display();
		sv.close();
	}
}
class LibraryTest{
	private String dept;
	private String name;
	private int code;
	public LibraryTest(String dept,String name,int code){
		this.dept=dept;
		this.name=name;
		this.code=code;
	}
	public void getData() {
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the values for change of dept,book name,code");
		this.dept=s.nextLine();
		this.name=s.nextLine();
		this.code=s.nextInt();
		s.nextLine();
	}
	public void display() {
		System.out.println(dept+" "+name+" "+code);
	}
}