package you;
import java.util.Scanner;
public class Main {
	public static void main(String[] args) {
		Scanner sv=new Scanner(System.in);
		System.out.println("Enter l1 and b1:");
		int l1=sv.nextInt();
		int b1=sv.nextInt();
		Rectangle rect1=new Rectangle(l1,b1);
		System.out.println("Enter l2 and b2:");
		int l2=sv.nextInt();
		int b2=sv.nextInt();
		Rectangle rect2=new Rectangle(l2,b2);
		System.out.println("Area of first rectangle: "+rect1.getArea());
		System.out.println("Area of second rectangle: "+rect2.getArea());
	}
}
class Rectangle{
	private int length;
	private int breadth;
	public Rectangle(int l,int b) {
		length=l;
		breadth=b;
	}
	public int getArea() {
		return length*breadth;
	}
}
