package SS;

public class main {
	public static void main(String[] args) {
		main n=new main();
		byte a=124;
		byte res=n.bytes(a);
		System.out.println(res);
		short temperature=32765;
		short ans=n.shorts(temperature);
		long range=-42332200000L;
		long sol=n.longs(range);
		System.out.println(sol);
		System.out.println(ans);
		double number=-42.3;
		double s=n.doubles(number);
		System.out.println(s);
		char letter='4';
		System.out.println(letter);
		char letter1=126;
		System.out.println(letter1);
		char ch='A';
		int asci=ch;
		System.out.println(asci);
		String result="\"This is in \uxxxx quotations\"";
		System.out.println(result);
		int b=100;
		char c=(char)b;
		System.out.println(c);
		short f=(short)b;
		System.out.println(f);
	}
	byte bytes(byte a) {
		return a;
	}
	short shorts(short temperature) {
		return temperature;
	}
	long longs(long range) {
		return range;
	}
	double doubles(double number) {
		return number;
	}
}
