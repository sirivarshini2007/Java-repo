package recursion;

import java.util.*;

class Road {
    String name;
    int vehicleCount;

    Road(String name, int vehicleCount) {
        this.name = name;
        this.vehicleCount = vehicleCount;
    }
}

class TrafficManagement {
    private Road[] roads;

    public TrafficManagement() {
        roads = new Road[] {
            new Road("Main Street", new Random().nextInt(100)),
            new Road("2nd Avenue", new Random().nextInt(100)),
            new Road("Highway 1", new Random().nextInt(100))
        };
    }

    public void monitorTraffic() {
        System.out.println("\n🚦 Traffic Status:");
        for (Road road : roads) {
            System.out.println(road.name + " - Vehicles: " + road.vehicleCount);
        }
    }

    public void adjustTrafficLights() {
        System.out.println("\n🔄 Adjusting traffic lights...");
        for (Road road : roads) {
            if (road.vehicleCount > 50) {
                System.out.println("⚠ High traffic on " + road.name + "! Increasing green light duration.");
            } else {
                System.out.println("✅ Traffic is normal on " + road.name + ".");
            }
        }
    }
}

class WasteBin {
    String location;
    int fillLevel;

    WasteBin(String location, int fillLevel) {
        this.location = location;
        this.fillLevel = fillLevel;
    }
}

class WasteManagement {
    private WasteBin[] bins;

    public WasteManagement() {
        bins = new WasteBin[] {
            new WasteBin("Downtown", new Random().nextInt(100)),
            new WasteBin("Suburb Area", new Random().nextInt(100)),
            new WasteBin("Industrial Zone", new Random().nextInt(100))
        };
    }

    public void checkWasteLevels() {
        System.out.println("\n🗑 Waste Bin Levels:");
        for (WasteBin bin : bins) {
            System.out.println(bin.location + " - Fill Level: " + bin.fillLevel + "%");
            if (bin.fillLevel > 80) {
                System.out.println("⚠ Waste bin at " + bin.location + " is almost full! Schedule pickup.");
            }
        }
    }
}

class EnergyZone {
    String type;
    int consumption;

    EnergyZone(String type, int consumption) {
        this.type = type;
        this.consumption = consumption;
    }
}

class EnergyManagement {
    private EnergyZone[] zones;

    public EnergyManagement() {
        zones = new EnergyZone[] {
            new EnergyZone("Residential", new Random().nextInt(500)),
            new EnergyZone("Commercial", new Random().nextInt(1000)),
            new EnergyZone("Industrial", new Random().nextInt(2000))
        };
    }

    public void monitorEnergy() {
        System.out.println("\n⚡ Energy Consumption:");
        for (EnergyZone zone : zones) {
            System.out.println(zone.type + " - Consumption: " + zone.consumption + " kWh");
            if (zone.consumption > 1500) {
                System.out.println("⚠ High energy usage in " + zone.type + "! Suggesting optimizations.");
            }
        }
    }
}

class PublicSafety {
    private List<String> emergencyReports = new ArrayList<>();

    public void reportIncident(String incident) {
        emergencyReports.add(incident);
        System.out.println("\n🚨 Emergency reported: " + incident);
        System.out.println("📡 Notifying nearest emergency response team...");
    }

    public void viewIncidents() {
        System.out.println("\n🛑 Reported Emergencies:");
        if (emergencyReports.isEmpty()) {
            System.out.println("✅ No active emergencies.");
        } else {
            for (String incident : emergencyReports) {
                System.out.println("⚠ " + incident);
            }
        }
    }
}

class SmartCityDashboard {
    private TrafficManagement traffic = new TrafficManagement();
    private WasteManagement waste = new WasteManagement();
    private EnergyManagement energy = new EnergyManagement();
    private PublicSafety safety = new PublicSafety();
    private Scanner scanner = new Scanner(System.in);

    public void startDashboard() {
        while (true) {
            System.out.println("\n=== 🌆 Smart City Dashboard ===");
            System.out.println("1. Monitor Traffic");
            System.out.println("2. Adjust Traffic Lights");
            System.out.println("3. Check Waste Levels");
            System.out.println("4. Monitor Energy Consumption");
            System.out.println("5. Report Emergency");
            System.out.println("6. View Emergency Incidents");
            System.out.println("7. Exit");
            System.out.print("Choose an option: ");

            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (choice) {
                case 1:
                    traffic.monitorTraffic();
                    break;
                case 2:
                    traffic.adjustTrafficLights();
                    break;
                case 3:
                    waste.checkWasteLevels();
                    break;
                case 4:
                    energy.monitorEnergy();
                    break;
                case 5:
                    System.out.print("Enter emergency report: ");
                    String incident = scanner.nextLine();
                    safety.reportIncident(incident);
                    break;
                case 6:
                    safety.viewIncidents();
                    break;
                case 7:
                    System.out.println("📴 Exiting Smart City Dashboard...");
                    return;
                default:
                    System.out.println("❌ Invalid choice. Try again.");
            }
        }
    }
}

public class SmartCitySystem {
    public static void main(String[] args) {
        SmartCityDashboard dashboard = new SmartCityDashboard();
        dashboard.startDashboard();
    }
}
