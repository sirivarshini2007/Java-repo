import java.util*;
public class H2 {
    public static void main(String[] args){
        Customer s=new Customer(300);
        Fooditem a=new Maincourse("idli",30,0);
        Fooditem b=new Dessert("blackforest",100,2);
        Fooditem c=new Beverage("coffee",200,2);
        try{
            s.placeorder(a);
            s.placeorder(b);
            s.placeorder(c);
        }
        catch(UnavailabeFoodException){
            System.out.println("Exception:"+e.getMessage());
        }
        try{
            a.select();
        }
        catch(InvalidQuantityException e){
            System.out.println("Exception:"+e.getMessage());
        }
        s.displayBookings();
        s.displayincome();
    }
}
class UnavailabeFoodException extends Exception{
    public UnavailabeFoodException(String msg){
        super(msg);
    }
}
class InvalidQuantityException extends Exception{
    public InvalidQuantityException(String msg){
        super(msg);
    }
}
abstract class Fooditem{
    String name;
    int cost;
    int Quantity;
    public boolean isAvailable=true;
    public Fooditem(String name,int cost,int Quantity){
        this.name=name;
        this.cost=cost;
        this.Quantity=Quantity;
    }
    public  boolean isAvailable(){
        return isAvailable;
    }
    public void select() throws UnavailabeFoodException{
        if(!isAvailable){
            throw new UnavailabeFoodException("not available"+name);
        }
        isAvailable=false;
    }
    public void release(){
        isAvailable=true;
    }
    public abstract String getType();
    public int getCost(){
        return cost;
    }
    public int getQuantity(){
        return Quantity;
    }
    public String getDetails(){
        return getType()+"cost:"+cost+"Quantity:"+Quantity;
    }
}
class Maincourse extends Fooditem{
    public Maincourse(String name,int cost,int Quantitiy){
        super(name,cost,Quantitiy);
    }
    public String getType(){
        return "Maincourse";
    }
}
class Dessert extends Fooditem{
    public Dessert(String name,int cost,int Quantitiy){
        super(name,cost,Quantitiy);
    }
    public String getType(){
        return "Dessert";
    }
}
class Beverage extends Fooditem{
    public Beverage(String name,int cost,int Quantitiy){
        super(name,cost,Quantitiy);
    }
    public String getType(){
        return "Beverage";
    }
}
class order {
    private List<Fooditem> bookings = new ArrayList<>();
    public void placeorder(Fooditem v)throws UnavailabeFoodException,InvalidQuantityException{
        for(Fooditem s:bookings){
            if(s.getType().equals(v.getType()){
                throw new UnavailabeFoodException(v.getType()+"is not available");
            }
        }
        v.select();
        bookings.add(v);
    }
}
class Customer extends order{
    private int bill;
    private int servicecharge=10;
    public Customer(int bill,int servicecharge){
        this.bill=bill;
        this.servicecharge=servicecharge;
    }
    bill+=v.getCost()+servicecharge;
    System.out.println("Booked"+v.getDetails());
    public void displayBookings(){
        System.out.printlb("Today's bookings:")
        for (Fooditem v:bookings){
            System.out.println(v.getDetails());
        }
    }
    public void displayincome(){
        System.out.println("Total Income for the day:"+bill);
    }
}

