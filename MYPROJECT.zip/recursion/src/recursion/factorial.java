package recursion;

import java.util.Scanner;
public class factorial {
	public static void main(String[] args) {
		Scanner sv=new Scanner(System.in);
		System.out.println("Enter the number:");
		int a=sv.nextInt();
		factorial n=new factorial();
		int res=n.fact(a);
		System.out.println("The factorial of"+a+":"+res);
	}
	int fact(int a) {
		if (a==0 || a==1) {
			return 1;
		}
		return a*fact(a-1);
	}
}
