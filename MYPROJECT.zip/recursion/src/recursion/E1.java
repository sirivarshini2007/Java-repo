package recursion;
import java.util.Scanner;
class E1 extends Thread{
	public void run() {
		System.out.println("Current thread running is");
	}
	public static void main(String[] args) {
		E1 m=new E1();
		m.setPriority(7);
		System.out.println("Priority of thread is :"+m.getPriority());
		m.start();
	}
}