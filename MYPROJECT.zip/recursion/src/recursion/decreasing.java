package recursion;

import java.util.Scanner;
public class decreasing {
	public static void main(String[] args) {
		Scanner sv=new Scanner(System.in);
		System.out.println("Enter n:");
		int n=sv.nextInt();
		print(n);
	}
	public static void print(int n) {
		if (n==0) {
			return;
		}
		System.out.print(n+" ");
		print(n-1);
		return;
	}
	
}
