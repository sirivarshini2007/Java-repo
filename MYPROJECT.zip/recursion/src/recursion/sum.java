package recursion;

import java.util.Scanner;
public class sum {
	public static void main(String[] args) {
		Scanner sv=new Scanner(System.in);
		System.out.println("Enter end number:");
		int a=sv.nextInt();
		sum n=new sum();
		int res=n.add(a);
		System.out.println("Sum of numbers:"+res);
	}
	int add(int a) {
		if (a==0) {
			return 0;
		}
		return a+add(a-1);
	}
}

