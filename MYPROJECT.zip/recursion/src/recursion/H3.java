import java.util.*;

// ------------------- Custom Exceptions -------------------
class BookNotAvailableException extends Exception {
    public BookNotAvailableException(String message) {
        super(message);
    }
}

class OverdueReturnException extends Exception {
    public OverdueReturnException(String message) {
        super(message);
    }
}

class BorrowLimitExceededException extends Exception {
    public BorrowLimitExceededException(String message) {
        super(message);
    }
}

// ------------------- Abstract Book Class -------------------
abstract class Book {
    protected String title;
    protected String author;
    protected boolean isAvailable = true;
    protected Member reservedBy = null;

    public Book(String title, String author) {
        this.title = title;
        this.author = author;
    }

    public boolean isAvailable() {
        return isAvailable;
    }

    public void setAvailable(boolean available) {
        this.isAvailable = available;
    }

    public void reserveBook(Member member) {
        this.reservedBy = member;
    }

    public boolean isReserved() {
        return reservedBy != null;
    }

    public Member getReservedBy() {
        return reservedBy;
    }

    public void clearReservation() {
        reservedBy = null;
    }

    public abstract String getType();

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }
}

// ------------------- Subclasses of Book -------------------
class TextBook extends Book {
    public TextBook(String title, String author) {
        super(title, author);
    }

    public String getType() {
        return "TextBook";
    }
}

class ReferenceBook extends Book {
    public ReferenceBook(String title, String author) {
        super(title, author);
    }

    public String getType() {
        return "ReferenceBook";
    }
}

class Journal extends Book {
    public Journal(String title, String author) {
        super(title, author);
    }

    public String getType() {
        return "Journal";
    }
}

// ------------------- Member Abstract Class -------------------
abstract class Member {
    protected String name;
    protected int borrowLimit;
    protected List<LoanRecord> currentLoans = new ArrayList<>();

    public Member(String name) {
        this.name = name;
    }

    public void borrowBook(Book book) throws Exception {
        if (currentLoans.size() >= borrowLimit) {
            throw new BorrowLimitExceededException("Borrowing limit exceeded.");
        }

        if (!book.isAvailable()) {
            if (book.isReserved() && book.getReservedBy() == this) {
                book.setAvailable(false);
                book.clearReservation();
                createLoan(book);
                System.out.println(name + " borrowed reserved book: " + book.getTitle());
            } else {
                throw new BookNotAvailableException("Book not available.");
            }
        } else {
            book.setAvailable(false);
            createLoan(book);
            System.out.println(name + " borrowed: " + book.getTitle());
        }
    }

    private void createLoan(Book book) {
        Date issueDate = new Date();
        Calendar cal = Calendar.getInstance();
        cal.setTime(issueDate);
        cal.add(Calendar.DAY_OF_MONTH, 14);
        Date dueDate = cal.getTime();

        LoanRecord record = new LoanRecord(book, this, issueDate, dueDate);
        currentLoans.add(record);
        LibrarySystem.addLoan(record);
    }

    public void returnBook(Book book) throws Exception {
        for (LoanRecord loan : currentLoans) {
            if (loan.getBook().equals(book)) {
                Date returnDate = new Date();
                long overdueDays = loan.calculateOverdueDays(returnDate);

                if (overdueDays > 0) {
                    double fine = overdueDays * 2;
                    loan.setFineAmount(fine);
                    loan.setReturnDate(returnDate);
                    LibrarySystem.addFine(fine);
                    throw new OverdueReturnException("Returned late. Fine: Rs." + fine);
                }

                book.setAvailable(true);
                if (book.getReservedBy() != null) {
                    System.out.println("Book " + book.getTitle() + " is reserved by " + book.getReservedBy().getName());
                }

                loan.setReturnDate(returnDate);
                currentLoans.remove(loan);
                System.out.println(name + " returned: " + book.getTitle());
                return;
            }
        }

        System.out.println("No record found for this book and user.");
    }

    public void reserveBook(Book book) {
        if (!book.isAvailable() && book.getReservedBy() == null) {
            book.reserveBook(this);
            System.out.println(name + " reserved the book: " + book.getTitle());
        } else {
            System.out.println("Book is available or already reserved.");
        }
    }

    public String getName() {
        return name;
    }
}

// ------------------- Student and Faculty Classes -------------------
class Student extends Member {
    public Student(String name) {
        super(name);
        this.borrowLimit = 3;
    }
}

class Faculty extends Member {
    public Faculty(String name) {
        super(name);
        this.borrowLimit = 5;
    }
}

// ------------------- Loan Record Class -------------------
class LoanRecord {
    private Book book;
    private Member member;
    private Date issueDate;
    private Date dueDate;
    private Date returnDate;
    private double fineAmount;

    public LoanRecord(Book book, Member member, Date issueDate, Date dueDate) {
        this.book = book;
        this.member = member;
        this.issueDate = issueDate;
        this.dueDate = dueDate;
    }

    public Book getBook() {
        return book;
    }

    public long calculateOverdueDays(Date returnDate) {
        long diff = returnDate.getTime() - dueDate.getTime();
        return diff > 0 ? diff / (1000 * 60 * 60 * 24) : 0;
    }

    public void setReturnDate(Date returnDate) {
        this.returnDate = returnDate;
    }

    public void setFineAmount(double fineAmount) {
        this.fineAmount = fineAmount;
    }

    @Override
    public String toString() {
        return "LoanRecord{" +
                "Book='" + book.getTitle() + '\'' +
                ", Member='" + member.getName() + '\'' +
                ", Issued=" + issueDate +
                ", Due=" + dueDate +
                ", Returned=" + (returnDate != null ? returnDate : "Not yet") +
                ", Fine=Rs." + fineAmount +
                '}';
    }
}

// ------------------- Library System with Main -------------------
public class H3{
    private static List<LoanRecord> allLoans = new ArrayList<>();
    private static double totalFines = 0;

    public static void addLoan(LoanRecord loan) {
        allLoans.add(loan);
    }

    public static void addFine(double fine) {
        totalFines += fine;
    }

    public static void displayFines() {
        System.out.println("Total fines collected today: Rs." + totalFines);
    }

    public static void displayLoans() {
        System.out.println("\nCurrent Loans:");
        for (LoanRecord lr : allLoans) {
            System.out.println(lr);
        }
    }

    public static void main(String[] args) {
        Book b1 = new TextBook("Java Basics", "James Gosling");
        Book b2 = new ReferenceBook("Data Structures", "Mark Weiss");
        Book b3 = new Journal("AI Trends", "IEEE");

        Member m1 = new Student("Alice");
        Member m2 = new Faculty("Dr. Bob");

        try {
            m1.borrowBook(b1);
            m2.borrowBook(b2);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        m1.reserveBook(b2); // Book already borrowed by m2

        try {
            Thread.sleep(1000); // simulate delay
            m2.returnBook(b2);  // Notify reservation
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        try {
            m1.borrowBook(b2); // Reserved borrow
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        displayLoans();
        displayFines();
    }
}
