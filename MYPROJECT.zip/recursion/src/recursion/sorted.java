package recursion;

public class sorted {
	public static void main(String[] args) {
		int [] arr= {1,2,7,4};
		int n=arr.length-1;
		sorted s=new sorted();
		String res=sort(n,arr);
		System.out.print("Array is"+res);
	}
	String sort(int n,int[] arr) {
		if(n==0) {
			return "done";
		}
		if(arr[n]<arr[n-1]) {
			return "not sorted";
		}
		sort(n-1,arr);
		return "restart";
	}
}
