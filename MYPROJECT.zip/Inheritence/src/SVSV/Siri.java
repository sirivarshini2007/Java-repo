package SVSV;

public class Siri{
	public static void main(String [] args) {
	 Manager B=new Manager();
	 B.getsal();
	}
}
class Employee{
	void getsal() {
		System.out.println("1 croroe to 2 crore");
	}
}
class Manager extends Employee{
	void getsal(){
		System.out.println("1.5 crore");
	}
}
class Developer extends Employee{
	void getsal(){
		System.out.println("1.8 crore");
	}
}

