package SVSV;

public class Q1{
	public static void main(String[] args) {
		int [] arr= {1,2,3,4};
		int target=3;
		int low=0;
		int high=arr.length-1;
		int res=binary(arr,target,low,high);
		System.out.println("The element is found at index :"+res);
	}
	static int binary(int [] arr,int target,int low,int high) {
		if(low==high) {
			return -1;
		}
		int mid=(low+high)/2;
		if(arr[mid]==target) {
			return mid;
		}
		if(arr[mid]>target) {
			return binary(arr,target,low,mid-1);
		}
		if(arr[mid]<target) {
			return binary(arr,target,mid+1,high);
		}
		return 0;
	}
}