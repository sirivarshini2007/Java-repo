package SVSV;

public class Siri1 {
	public static void main(String [] args) {
		Bike B=new Bike();
		B.helmet();
	}
}
class Vehicle{
	void start() {
		System.out.println("HEllo");
	}
}
class Bike extends Vehicle{
	void helmet() {
		super.start();
		System.out.println("HI");
	}
}
class Car extends Vehicle{
	void seatbelt() {
		super.start();
		System.out.println("HIo");
	}
}
