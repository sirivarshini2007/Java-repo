package SVSV;

public class Siri3{
	public static void main(String[] args) {
		Student p=new Student("HELLO",23);
	}
}
class Person{
	public String name;
	Person(String name){
		this.name=name;
	}
}
class Student extends Person{
	int rollno;
	Student(String name,int rollno){
		super(name);
		this.rollno=rollno;
		System.out.println(name+rollno);
	}
}