package OOPS;

public class Q7 {
	public static void main(String[] args) {
		Student siri=new Student();
		siri.greeting();
	}
}
class Student{
	int rollno;
	String name;
	float marks;
	void greeting() {
		System.out.println("Hello"+name);
	}
	Student(){
		this.rollno=58;
		this.name="Siri";
		this.marks=589;
	}
}
