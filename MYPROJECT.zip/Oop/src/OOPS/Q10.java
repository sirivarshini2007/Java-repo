package OOPS;

public class Q10 {
	public static void main(String[] args) {
		int a=10;
		int b=20;
		Integer num=45;
		System.out.println(a+"hello"+b);
		swap(a,b);
		final A kunal=new A("SIRI");
		kunal.name="other name";
		System.out.println(kunal.name);
	}
	static void swap(int a,int b) {
		int temp=a;
		a=b;
		b=temp;
	}
}
class A{
	final int num=10;
	String name;
	public A(String name) {
		this.name=name;
	}
}
