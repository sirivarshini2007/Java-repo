package OOPS;

import java.util.Scanner;
public class Q5 {
	public static void main(String[] args) {
		Scanner sv=new Scanner(System.in);
		Varshi [] st=new Varshi[5];
		for (int i=0;i<5;i++) {
			System.out.println("Enter your name:");
			String name=sv.next();
			System.out.println("Enter your marks:");
			int marks=sv.nextInt();
			st[i]=new Varshi();
			st[i].setDetails(name,marks);
		}
		for(int i=0;i<5;i++) {
			st[i].printDetails();
		}
	}
}
class Varshi{
	private String name;
	private int marks;
	public void setDetails(String n,int m) {
		name=n;
		marks=m;
	}
	public void printDetails() {
		System.out.println("Name:"+name);
		System.out.println("Marks"+marks);
	}
}
