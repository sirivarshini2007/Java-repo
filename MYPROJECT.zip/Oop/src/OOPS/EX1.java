package OOPS;

public class EX1 {
	public static void main(String [] args) {
		ECE [] s=new ECE[2];
		s[0]=new ECE(2,3);
		s[1]=new ECE(4,5);
		for(int i=0;i<2;i++) {
			System.out.println(s[i].getArea());
		}
	}
}
class ECE{
	int length;
	int breadth;
	ECE(int l,int m){
		length=l;
		breadth=m;
	}
	int getArea() {
		return length*breadth;
	}
}
