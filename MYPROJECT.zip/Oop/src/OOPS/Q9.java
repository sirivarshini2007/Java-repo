package OOPS;

public class Q9 {
	public static void main(String [] args) {
		Student one =new Student();
		Student two=one;
		one.name="MISSW";
		System.out.println(two.name);
	}
}
class Student{
	int rollno;
	String name;
	float marks;
	Student(){
		this.rollno=rollno;
		this.name=name;
		this.marks=marks;
	}
}
