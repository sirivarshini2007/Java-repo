package OOPS;

public class Q11 {
	public static void name(String[] args) {
		ECE s=new ECE();
		Student1.setName("null");
		Ssytem.out.println(s.name);
	}
}
class ECE{
	int rollno;
	String name;
	int mobile;
	public void setName(String n) {
		this.name=n;
	}
}
