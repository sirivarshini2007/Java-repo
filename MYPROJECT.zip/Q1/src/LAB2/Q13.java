package LAB2;

import java.util.Scanner;

public class Q13 {
	public static void main(String[] args) {
		Scanner sv=new Scanner(System.in);
		System.out.println("Enter a number:");
		int a=sv.nextInt();
		Q13 n=new Q13();
		n.table(a);
	}
	void table(int a) {
		int i=1;
		while(i<=10) {
			System.out.println(a+"*"+i+"="+a*i);
			i=i+1;
		}
	}
}
