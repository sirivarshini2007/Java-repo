package LAB2;

import java.util.Scanner;

public class Q9 {
	public static void main(String [] args) {
		Scanner sv=new Scanner(System.in);
		System.out.println("Enter a number");
		int a=sv.nextInt();
		Q9 n=new Q9();
		System.out.println("The factors of "+a+" are:");
		n.divisor(a);
	}
	void divisor(int a) {
		for (int i=1;i<=a;i++) {
			if (a%i==0) {
				System.out.print(i+" ");
			}
		}
	}
}
