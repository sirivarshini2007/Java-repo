package LAB2;

import java.util.Scanner;

public class Q15 {
	public static void main(String[] args) {
		Scanner sv=new Scanner(System.in);
		System.out.println("Enter a number:");
		int a=sv.nextInt();
		Q15 n=new Q15();
		n.right(a);
	}
	void right(int a) {
		for (int i=0;i<a;i++) {
			for(int j=0;j<=i;j++) {
				System.out.print("*");
			}
			System.out.println();
		}
	}
}
