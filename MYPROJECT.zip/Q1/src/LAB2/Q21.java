package LAB2;

public class Q21 {
	static int dividebyzero(int a,int b) {
		int i=a/b;
		return i;
	}
	static int compute(int a,int b) {
		int res=0;
		try {
			res=dividebyzero(a,b);
		}
		catch(NumberFormatException e) {
			System.out.println(e);
		}
		return res;
	}
	public static void main(String[] args) {
		int a=1;
		int b=5;
		try {
			int ans=compute(a,b);
		}
		catch(ArithmeticException e) {
			System.out.println("Arithmetic error in main: " + e.getMessage());
		}
		catch(Exception e) {
			System.out.println(e);
		}
	}
}
