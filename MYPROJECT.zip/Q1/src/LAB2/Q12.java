package LAB2;

import java.util.Scanner;

public class Q12 {
	public static void main(String[] args) {
		Scanner sv=new Scanner(System.in);
		System.out.println("Enter three numbers");
		int a=sv.nextInt();
		int b=sv.nextInt();
		int c=sv.nextInt();
		Q12 n=new Q12();
		n.prime1(a);
	}
	void prime1(int a) {
		for (int i=0;i<=a;i++) {
			int d=a%i;
			int count=0;
			for(int j=1;j<=d;j++) {
				if(d%j==0) {
					count=count+1;
				}
			}
			if (count==2) {
				System.out.print(d+" ");
			}
		}
	}
}
