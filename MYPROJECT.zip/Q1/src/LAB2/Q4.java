package LAB2;

import java.util.Scanner;

public class Q4 {
	public static void main(String[] args) {
		Scanner sv=new Scanner(System.in);
		System.out.println("Enter three numbers");
		int a=sv.nextInt();
		int b=sv.nextInt();
		int c=sv.nextInt();
		Q4 n=new Q4();
		int res=n.check(a,b,c);
		System.out.print("The  largest number is: "+res);
	}
	int check(int a,int b,int c) {
		if(a>b && a>c) {
			return a;
		}
		else if(b>a && b>c) {
			return b;
		}
		else {
			return c;
		}
	}
}
