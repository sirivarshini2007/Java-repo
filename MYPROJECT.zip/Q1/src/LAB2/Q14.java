package LAB2;

import java.util.Scanner;

public class Q14 {
	public static void main(String[] args) {
		Scanner sv=new Scanner(System.in);
		System.out.println("Enter a number:");
		int a=sv.nextInt();
		Q14 n=new Q14();
		n.table(a);
	}
	void table(int a) {
		for(int i=1;i<=10;i++) {
			System.out.println(a+"*"+i+"="+a*i);
		}
	}
}
