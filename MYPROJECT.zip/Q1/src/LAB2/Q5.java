package LAB2;

import java.util.Scanner;

public class Q5 {
	public static void main(String[] args) {
		Scanner sv=new Scanner(System.in);
		System.out.println("Enter your average marks");
		int a=sv.nextInt();
		Q5 n=new Q5();
		String res=n.check(a);
		System.out.print("Your grade is: "+res);
	}
	String check(int a) {
		if (a>=80) {
			return "A";
		}
		else if(a>60 && a<=80) {
			return "B";
		}
		else if(a>40 && a<=60) {
			return "C";
		}
		else {
			return "F";
		}
	}
}
