package LAB2;

import java.util.Scanner;

public class Q18 {
	public static void main(String[] args) {
		Scanner sv=new Scanner(System.in);
		System.out.println("Enter a number:");
		int a=sv.nextInt();
		Q18 n=new Q18();
		String res=n.arm(a);
		System.out.print(res);
	}
	String arm(int a) {
		int tem=a;
		int count=0;
		while(a%10>0) {
			count=count+1;
			a=a/10;
		}
		int p=count;
		a=tem;
		int sum=0;
		while(a>0) {
			int d=a%10;
			sum+=Math.pow(d,p);
			a=a/10;
		}
		if(tem==sum) {
			return "Armstrong number";
		}
		else {
			return "Not an Armstrong number";
		}	
	}
}