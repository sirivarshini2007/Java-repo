package LAB2;

import java.util.Scanner;

public class Q6 {
	public static void main(String[] args) {
		Scanner sv=new Scanner(System.in);
		System.out.println("Enter a value");
		char a=sv.next().charAt(0);
		Q6 n=new Q6();
		int  res=n.check(a);
		System.out.print("your points are:"+res);
	}
	int check(char a) {
		if (Character.isUpperCase(a)) {
			if (a=='A' || a=='I' || a=='E' || a=='O' || a=='U') {
				return 5;
			}
		}
		else if (Character.isLowerCase(a)) {
			if (a=='a' || a=='e' || a=='i' || a=='o' || a=='u') {
				return 5;
			}
		}
		else if (Character.isDigit(a)) {
			return 10;
		}
		else {
			return 0;
		}
		return 0;
	}
}
