package LAB2;

import java.util.Scanner;
public class Q3 {
	public static void main(String[] args) {
		Scanner sv=new Scanner(System.in);
		System.out.println("Enter your age:");
		int a=sv.nextInt();
		Q3 n=new Q3();
		String res=n.voting(a);
		System.out.print(res);
	}
	String voting(int a) {
		if(a>=18) {
			return "you are eligible to vote";
		}
		else {
			return "you are not eligible to vote";
		}
	}
}
