package LAB2;

import java.util.Scanner;

public class Q7 {
	public static void main(String[] args) {
		Scanner sv=new Scanner(System.in);
		System.out.println("Enter three numbers");
		int a=sv.nextInt();
		int b=sv.nextInt();
		int c=sv.nextInt();
		Q7 n=new Q7();
		int res=n.check(a,b,c);
		System.out.print("Your points are: "+res);
	}
	int check(int a,int b,int c) {
		int d=b*b-4*a*c;
		if(d>0) {
			return 30;
		}
		else if(d==0) {
			return 20;
		}
		else {
			return 10;
		}
	}
}
