package Hii;
import java.util.*;
import java.util.Scanner;
public class CourseSystem {
	static int num=0;
	static int cnum=0;
	static int nnum=0;
	static int anum=0;
	public static void main(String[] args) {
		Scanner sv=new Scanner(System.in);
		System.out.println("Enter regno:");
		int b=sv.nextInt();
		while(b>0) {
			System.out.println("Enter name:");
			String a=sv.next();
			System.out.println("Enter tenth:");
			int c=sv.nextInt();
			System.out.println("Enter twth:");
			int d=sv.nextInt();
			Student s=new Student(a,b,c,d);
			num+=1;
		}
		System.out.println("List of courses :1.Core,2.Elective,3.Audit");
		System.out.println("Enter course name");
		String p=sv.next();
		System.out.println("Enter your choice:");
		int choice=sv.nextInt();
		Course s=new Core(p,1);
		switch(choice) {
		case 1:
			System.out.println("Core selected");
			cnum+=1;
			break;
		case 2:
			System.out.println("Elective selected");
			nnum+=1;
			break;
		case 3:
			System.out.println("Audit selected");
			anum+=1;
			break;
		default:
			System.out.println("invalid choice");
		}
	}
}
class Student{
	String name;
	int regno;
	int tenth;
	int twth;
	Student(String name,int regno,int tenth,int twth){
		this.name=name;
		this.regno=regno;
		this.tenth=tenth;
		this.twth=twth;
	}
	public void check() throws PreRequisitesException{
		if(name==null|| regno==0 || tenth<=70 || twth<=80) {
			throw new PreRequisitesException("Information not filled properly");
		}
	}
	public String getdetails() {
		return name+regno+tenth+twth+"is the information";
	}
	
}
abstract class Course{
	String cname;
	int cid;
	Course(String cname,int cid){
		this.cname=cname;
		this.cid=cid;
	}
	abstract String getname();
	abstract int getcount();
}
class Core extends Course{
	String cname;
	int cid;
	private final int max=10;
	Core(String cname,int cid){
		super(cname,cid);
	}
	public String getname() {
		return cname;
	}
	public int getcount() {
		return CourseSystem.cnum;
	}
}
class Elective extends Course{
	String cname;
	int cid;
	private final int maxi=9;
	Elective(String cname,int cid){
		super(cname,cid);
	}
	public String getname() {
		return cname;
	}
	public int getcount() {
		return CourseSystem.nnum;
	}
}
class Audit extends Course{
	String cname;
	int cid;
	private final int maxx=6;
	Audit(String cname,int cid){
		super(cname,cid);
	}
	public String getname() {
		return cname;
	}
	public int getcount() {
		return CourseSystem.anum;
	}
}
class Registration{
	private List<String>people=new ArrayList<>();
	int count=5;
	Registration(int count){
		this.count=count;
	}
	people.add(Course.cname);
	public void see(CourseSystem c) throws MaximumCapacityException{
		if (c.num==count) {
			throw new  MaximumCapacityException("The limit reached");
		}
	}
	public void display() {
		for(Registration s:people) {
			System.out.println(s);
		}
	}
}
class PreRequisitesException extends Exception{
	public PreRequisitesException(String msg) {
		super(msg);
	}
}
class MaximumCapacityException extends Exception{
	public MaximumCapacityException(String msg) {
		super(msg);
	}
}