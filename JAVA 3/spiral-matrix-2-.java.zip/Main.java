/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
		Scanner sv=new Scanner(System.in);
		System.out.print("Enter the value of n:");
		int n=sv.nextInt();
		int [][] res=new int[n][n];
		spiral(n,res);
	}
	static void spiral(int n,int[][] res){
	    int sr=0;
	    int er=n-1;
	    int sc=0;
	    int ec=n-1;
	    int k=1;
	    while(sr<=er && (sc<=ec && k<=n*n)){
	        for(int i=sc;i<=ec;i++){
	            res[sr][i]=k++;
	    }
	        for(int j=sr+1;j<=er;j++){
	            res[j][ec]=k++;
	    }
	        for(int s=ec-1;s>=sc;s--){
	            res[er][s]=k++;
	    }
	        for(int l=er-1;l>sr;l--){
	            res[l][sc]=k++;
	    }
	        sr++;
	        sc++;
	        er--;
	        ec--;
	    
	  }
	  for (int h=0;h<n;h++){
	      for(int u=0;u<n;u++){
	          System.out.print(res[h][u]+" ");
	      }
	      System.out.println();
	  }
	}
}
