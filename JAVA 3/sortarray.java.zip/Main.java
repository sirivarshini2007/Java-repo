/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Arrays;
public class Main
{
	public static void main(String[] args) {
		int [] nums={2,0,2,1,1,0};
		sort(nums);
	}
	static void sort(int [] nums){
	    Arrays.sort(nums);
	    for(int x:nums){
	        System.out.print(x+" ");
	    }
	}
}
