/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
		Scanner sv= new Scanner(System.in);
		System.out.print("Enter rows:");
		int r=sv.nextInt();
		System.out.print("Enter cols:");
		int c=sv.nextInt();
		int [][] arr=new int[r][c];
		int k=1;
		for(int i=0;i<r;i++){
		    for(int j=0;j<c;j++){
		        arr[i][j]=k++;
		    }
		}
		System.out.print("Enter rstart:");
		int rstart=sv.nextInt();
		System.out.print("Enter cstart:");
		int cstart=sv.nextInt();
		spiral(r,c,rstart,cstart);
	}
	static void spiral(int r,int c,int rstart,int cstart){
	    int sr=0;
	    int sc=0;
	    int er=r-1;
	    int ec=c-1;
	    for(int i=cstart;i<=ec;i++){
	        System.out.println(rstart+","+i);
	    }
	    for(int j=rstart;j<=er;j++){
	        System.out.println(j+","+ec);
	    }
	    for(int k=ec-1;k>=sc;k++){
	        System.out.println(er+","+k);
	    }
	    for(int l=er-1;l>=sr;l++){
	        System.out.println(l+","+sc);
	    }
	    if (rstart==0 && cstart==0){
	        for(int h=sc+1;h<=ec;h++){
	            System.out.println(sr+","+h);
	        }
	    }
	}
}
