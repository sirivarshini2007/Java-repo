/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
		int [] nums={7,8,9,12};
		int [] arr=new int[1000];
		int c=1;
		for(int i=0;i<arr.length;i++){
		    arr[i]=c++;
		}
		missingpositive(nums,arr);
	}
	static void missingpositive(int [] nums,int [] arr){
	    int res=0;
	    int ans=0;
	    int fab=0,sol=0;
	    for(int j=0;j<nums.length;j++){
	        res=Math.min(res,nums[j]);
	        ans=Math.max(ans,nums[j]);
	    }
	    for(int k=0;k<arr.length;k++){
	        if(arr[k]>res && arr[k]<ans){
	            fab=Math.min(fab,arr[k]);
	            sol=Math.max(sol,arr[k]);
	        }
	    }
	    for (int h=0;h<arr.length;h++){
	        if(arr[h]>fab && arr[h]<sol){
	            System.out.print(arr[h]);
	        }
	    }
	}
}
