/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
		int [][] arr={{1,1,1},{1,0,1},{1,1,1}};
		setzero(arr);
	}
	static void setzero(int [][] arr){
	    int rows=arr.length;
	    int cols=arr[0].length;
	    boolean [] rowFlags=new boolean[rows];
	    boolean [] colFlags=new boolean[cols];
	    for (int i=0;i<rows;i++){
	        for(int j=0;j<cols;j++){
	            if(arr[i][j]==0){
	                rowFlags[i]=true;
	                colFlags[j]=true;
	            }
	        }
	    }
	    for (int i=0;i<rows;i++){
	        for(int j=0;j<cols;j++){
	            if (rowFlags[i] || colFlags[j]){
	                arr[i][j]=0;
	            }
	        }
	    }
	    for (int i=0;i<arr.length;i++){
	        for(int j=0;j<arr[0].length;j++){
	            System.out.print(arr[i][j]+" ");
	        }
	        System.out.println();
	    }
	}
}
