/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
	    int r,k,h,l;
		int [][] arr={{1,1,1},{1,0,1},{1,1,1}};
		setzero(arr,r,k,h,l);
	}
	static void setzero(int [][] arr,int r,int k,int h,int l){
	    int sr=0;
	    int sc=0;
	    int er=arr.length-1;
	    int ec=arr[0].length-1;
	    for(int i=0;i<arr.length;i++){
	        for(int j=0;j<arr.length;j++){
	            if(arr[i][j]==0){
	                while(r>=sr && r<=i && k>=sc && k<=j){
	                    arr[r][k]=0;
	                    r++;
	                    k++;
	                }
	                while(h>=i && r<=er && l>=j && l<=ec){
	                    arr[h][l]=0;
	                    h++;
	                    l++;
	                }
	            }
	        }
	    }
	    for (int s=0;s<arr.length;s++){
	        for(int u=0;u<arr[0].length;u++){
	            System.out.println(arr[s][u]);
	        }
	        System.out.println();
	    }
	}
}
