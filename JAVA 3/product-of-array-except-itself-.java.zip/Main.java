/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/

import java.util.Scanner;
import java.util.List;
import java.util.ArrayList;
public class Main
{
	public static void main(String[] args) {
		Scanner sv=new Scanner(System.in);
		String res=sv.nextLine();
		String[] nums=res.split(" ");
		List<Integer>ans=new ArrayList<>();
		for(String num:nums){
		    ans.add(Integer.parseInt(num));
		}
		System.out.println(ans);
		List<Integer>sol=exceptproduct(ans);
		System.out.print(sol);
	}
	static List<Integer> exceptproduct(List<Integer>ans){
	    List<Integer>sol=new ArrayList<>();
	    int prod=1;
	    for(int i=0;i<ans.size();i++){
	        prod=prod*ans.get(i);
	    }
	    for(int j=0;j<ans.size();j++){
	        sol.add(prod/ans.get(j));
	    }
	    return sol;
	}
}