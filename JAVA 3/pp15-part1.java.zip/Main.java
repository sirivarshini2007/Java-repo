/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/

public class Main
{
	public static void main(String[] args) {
	    int n=10;
	    System.out.print("*");
	    System.out.println();
		for(int i=1;i<n-i;i++){
		    System.out.print(" ");
		    for(int j=1;j<=2;j++){
		        for(int k=1;k<i;k++){
		            System.out.print(" ");
		        }
		        System.out.print("*");
		    }
		    System.out.println();
		}
		int s=4;
	    for(int i=1;i<s;i++){
		    System.out.print(" ");
		    for(int j=1;j<=2;j++){
		        for(int k=1;k<(s-i);k++){
		            System.out.print(" ");
		        }
		        System.out.print("*");
		    }
		    System.out.println();
		}
		System.out.print("*");
	    System.out.println();
	}
}