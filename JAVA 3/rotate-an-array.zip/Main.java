/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
		Scanner sv=new Scanner(System.in);
		String ans=sv.nextLine();
		System.out.print("Enter number to be rotated:");
		int k=sv.nextInt();
		int [] sol={1,2,3,4,5,6,7};
		rotate(sol,k);
	}
	static void rotate(int [] sol,int k){
	    int m=sol.length;
	    for(int i=0;i<m/2;i++){
	        int temp=sol[i];
	        sol[i]=sol[i+k+1];
	        sol[i+k+1]=temp;
	    }
	    for(int j=0;j<m;j++){
	        System.out.print(sol[j]);
	    }
	}
}
