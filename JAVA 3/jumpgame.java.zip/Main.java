/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;
public class Main
{
	public static void main(String[] args) {
		Scanner sv=new Scanner(System.in);
		String ans=sv.nextLine();
		String[] res=ans.split(" ");
		List<Integer>sol=new ArrayList<>();
		for(String n:res){
		    sol.add(Integer.parseInt(n));
		}
		System.out.println(sol);
		jumpgame(sol);
	}
	static void jumpgame(List<Integer> sol){
	    int m=sol.size();
	    int steps=0;
	    for(int i=0;i<m;i++){
	        for(int j=0;j<sol.get(i);j++){
	            steps=steps+j;
	        }
	        if(steps==m-1){
	                System.out.println("true");
	                break;
	            }
	    }
	}
}
