/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;
import java.util.List;
import java.util.ArrayList;
public class Main
{
	public static void main(String[] args) {
		Scanner sv=new Scanner(System.in);
		System.out.print("Enter target integer");
		int target=sv.nextInt();
		sv.nextLine();
		System.out.print("Enter list of numbers:");
		String ans=sv.nextLine();
		String[] res=ans.split(" ");
		List<Integer>nums=new ArrayList<>();
		for(String num:res){
		    nums.add(Integer.parseInt(num));
		}
		System.out.println(nums);
		List<Integer>sol=position(nums,target);
		System.out.print(sol);
	}
	static List<Integer> position(List<Integer>nums,int target){
	    List<Integer>sol=new ArrayList<>();
	    for(int i=0;i<nums.size();i++){
	        if(nums.get(i)==target){
	            sol.add(i);
	        }
	        else{
	            sol.add(-1);
	        }
	    }
	    return sol;
	}
}
