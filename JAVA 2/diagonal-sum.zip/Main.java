/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
		int [][] arr=new int[3][3];
		int c=1;
		for(int i=0;i<arr.length;i++){
		    for(int j=0;j<arr.length;j++){
		        arr[i][j]=c++;
		        System.out.print(arr[i][j]+" ");
		    }
		    System.out.println();
		}
		diagonalsum(arr);
	}
	static void diagonalsum(int [][] arr){
	    int sum=0;
	    int i=0;
	    int j=0;
	    int k=arr.length-1;
	    while(i<arr.length && k>=0){
	        sum+=arr[i][j];
	        sum+=arr[i][k];
	        if(k==j){
	            sum-=arr[i][k];
	        }
	        i++;
	        j++;
	        k--;
	    }
	    System.out.print("diagonalsum "+sum);
	}
}
