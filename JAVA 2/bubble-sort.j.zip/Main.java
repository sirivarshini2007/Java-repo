/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
public class Main{
    public static void main(String[] args){
        int [] arr={6,7,1,2};
        sort(arr);
        for (Integer i:arr){
            System.out.print(i+" ");
        }
    }
    static void sort(int [] arr){
        int n=arr.length;
        for(int turns=0;turns<n;turns++){
            for(int i=0;i<n-1;i++){
                int curr=arr[i];
                int next=arr[i+1];
                if(next>curr){
                    swap(i,arr);
                }
            }
        }
    }
    static void swap(int i,int [] arr){
        int temp=arr[i];
        arr[i]=arr[i+1];
        arr[i+1]=temp;
    }
    
}