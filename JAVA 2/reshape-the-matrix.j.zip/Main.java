/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
		int [][] arr={{1,2},{3,4}};
		reshape(arr);
	}
	static void reshape(int [][] arr){
	    Scanner sv=new Scanner(System.in);
	    System.out.print("Enter r:");
	    int r=sv.nextInt();
	    System.out.print("Enter c:");
	    int c=sv.nextInt();
	    if(arr.length*arr[0].length<=r*c){
	        for(int i=0;i<arr.length;i++){
	            for(int j=0;j<arr.length;j++){
	                System.out.print(arr[i][j]+" ");
	            }
	        }
	    }
	    else{
	        for(int i=0;i<r;i++){
	            for(int j=0;j<c;j++){
	                System.out.print(arr[i][j]+" ");
	            }
	        }
	    }
	}
}
