/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Arrays;
public class Main
{
	public static void main(String[] args) {
		int [] nums={2,1,5};
		int k=806;
		arrayform(nums,k);
	}
	static void arrayform(int [] nums,int k){
	    int num=0;
	    for(int i=0;i<nums.length;i++){
	        num=num*10+nums[i];
	    }
	    int res=num+k;
	    String ans=Integer.toString(res);
	    int [] val= new int[ans.length()];
	    for(int j=0;j<ans.length();j++){
	        val[j]=Character.getNumericValue(ans.charAt(j));
	    }
	    System.out.print(Arrays.toString(val)+" ");
	}
}
