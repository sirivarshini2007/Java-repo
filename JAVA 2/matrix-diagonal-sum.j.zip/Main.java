/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
		int [][] mat={{1,1,1,1},{1,1,1,1},{1,1,1,1},{1,1,1,1}};
		diagonal_sum(mat);
	}
	static void diagonal_sum(int [][] mat){
	    int primarydiagonal_sum=0;
	    int secondarydiagonal_sum=0;
	    int diagonalsum;
	    for(int i=0;i<mat.length;i++){
	        primarydiagonal_sum+=mat[i][i];
	        secondarydiagonal_sum+=mat[mat.length-1-i][i];
	    }
	    int c=primarydiagonal_sum+secondarydiagonal_sum;
	    diagonalsum=c;
	    if((mat.length)%2!=0){
	        diagonalsum=c-mat[(mat.length-1)/2][(mat.length-1)/2];
	    }
	    System.out.print(diagonalsum);
	}
}
