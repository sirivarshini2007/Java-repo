/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
		int [] gain={-5,1,5,0,-7};
		highest_altitude(gain);
	}
	static void highest_altitude(int [] gain){
	    int current_altitude=0;
	    int max_altitude=0;
	    for(int i=0;i<gain.length;i++){
	        current_altitude+=gain[i];
	        max_altitude=Math.max(max_altitude,current_altitude);
	    }
	    System.out.print(max_altitude);
	}
}
