/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
		String items [][]={{"phone","blue","pixel"},{"computer","silver","lenovo"},{"phone","gold","iphone"}};
		String rulekey="phone";
		String rulevalue="blue";
		check(items,rulekey,rulevalue);
	}
	static void check(String [][] items,String rulekey,String rulevalue){
	    int count=0;
	    int n=items.length;
	    for(int i=0;i<n;i++){
	        if(items[i][0].equals(rulekey)&&
	           items[i][1].equals(rulevalue)){
	               count+=1;
	           }
	    }
	    System.out.print(count);
	}
}
