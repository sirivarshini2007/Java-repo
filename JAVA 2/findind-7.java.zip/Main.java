/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/

class Main {
    public static void main(String[] args) {
        int [][] arr={{4,7,8},{8,8,7}};
        int target=7;
        int res=gettarget(arr,target);
        System.out.print(res);
    }
    public static int gettarget(int [][] arr,int target){
        int count=0;
        for(int i=0;i<arr.length;i++){
            for(int j=0;j<arr[0].length;j++){
                if(arr[i][j]==target){
                    count++;
                }
            }
        }
        return count;
    }
}