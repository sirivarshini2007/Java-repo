/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/

public class Main
{
	public static void main(String[] args) {
		int [][] arr=new int [3][3];
		int c=1;
		for(int i=0;i<arr.length;i++){
		    for(int j=0;j<arr.length;j++){
		        arr[i][j]=c++;
		    }
		}
		spiralmatrix(arr);
	}
	static void spiralmatrix(int [][] arr){
	    int sr=0;
	    int sc=0;
	    int er=arr.length-1;
	    int ec=arr.length-1;
	    while(sr<=er && sc<=ec){
	        for(int i=sc;i<=ec;i++){
	            System.out.print(arr[sr][i]);
	    }
	        for (int k=sr+1;k<=er;k++){
	            System.out.print(arr[k][ec]);
	    }
	        for(int l=ec-1;l>=sc;l--){
	            System.out.print(arr[er][l]);
	    }
	        for(int s=er-1;s>sr;s--){
	            System.out.print(arr[s][sc]);
	    }
	    sr++;
	    sc++;
	    er--;
	    ec--;
	    }
	}
}