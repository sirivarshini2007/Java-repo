/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main{
    public static void main(String [] args){
        int [] candies={2,3,5,1,3};
        int extracandies=3;
        boolean [] ans=check(candies,extracandies);
    }
    static void check(int [] candies,int extracandies){
        int n=candies.length;
        boolean [] ans=new boolean[];
        int maxi=0;
        for (int j=0;j<n;j++){
            maxi=Math.max(candies[j],maxi);
        }
        for(int i=0;i<n;i++){
            ans[i]=(candies[i]+extracandies>=maxi);
        }
        for(int k=0;k<n;k++){
            System.out.print(ans[k]);
        }
    }
}
