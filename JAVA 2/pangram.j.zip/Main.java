/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
		Scanner sv=new Scanner(System.in);
		String input=sv.nextLine().toLowerCase();
		pangram(input);
	}
	static void pangram(String input){
	    int avg=0;
	    int length=input.length();
	    for(int i=0;i<length;i++){
	        char c=input.charAt(i);
	        avg+=(int)c;
	    }
	    if(avg>=2847){
	        System.out.print("true");
	    }
	    else{
	        System.out.print("false");
	    }
	}
}
