/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
		int [] arr={1,2,3,4,5,6};
		maxsubarray(arr);
	}
	static void maxsubarray(int [] arr){
	    int max=Integer.MIN_VALUE;
	    int start=0,end=0;
	    for(int i=0;i<arr.length;i++){
	        for(int j=i;j<arr.length;j++){
	            int sum=0;
	           for(int k=i;k<=j;k++){
	               sum+=arr[k];
	           }
	           if(sum>max){
	               max=sum;
	               start=i;
	               end=j;
	           }
	        }
	    }
	    System.out.print("Maxsubarray:");
	    for(int k=start;k<=end;k++){
	        System.out.print(arr[k]+" ");
	    }
	    System.out.println("Maxsum:"+max);
	}
}
