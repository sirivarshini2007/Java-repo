/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
		int [] arr={1,2,3};
		subarray(arr);
	}
	static void subarray(int [] arr){
	    for(int i=0;i<arr.length;i++){
	        for(int j=i;j<arr.length;j++){
	            for(int k=i;k<=j;k++){
	                System.out.print(arr[k]+" ");
	            }
	        }
	    }
	}
}
