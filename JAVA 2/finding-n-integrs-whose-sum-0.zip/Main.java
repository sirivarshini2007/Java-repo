/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main{
    public static void main(String[] args){
        int n=3;
        sumzero(n);
    }
    static void sumzero(int n){
        int [] result=new int[n];
        int index=0;
        for(int i=0;i<n/2;i++){
            result[index++]=i;
            result[index++]=-i;
        }
        if(n%2!=0){
            result[index]=0;
        }
        for(int j=0;j<n;j++){
            System.out.print(result[j]+" ");
        }
    }
}