/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/

public class Main
{
	public static void main(String[] args) {
		int [] nums={1,1,2};
		duplicate(nums);
	}
	static void duplicate(int [] nums){
	    for(int i=0;i<nums.length;i++){
	        for(int j=i+1;j<nums.length;j++){
	            if(nums[i]==nums[j] && nums[j]!=0){
	               nums[j]=0;
	            }
	        }
	    }
	    for(int k=0;k<nums.length;k++){
	        System.out.print(nums[k]);
	    }
	}
}
