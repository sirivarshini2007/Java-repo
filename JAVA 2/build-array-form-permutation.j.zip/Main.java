/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
		int [] nums={0,2,1,5,3,4};
		int [] ans=new int[nums.length];
		for(int i=0;i<nums.length;i++){
		    ans[i]=nums[nums[i]];
		}
		for(int j=0;j<nums.length;j++){
		    System.out.print(ans[j]);
		}
	}
}
