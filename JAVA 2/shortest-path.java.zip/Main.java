/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
		String str="WNEENESENNN";
		int x=0;
		int y=0;
		System.out.print(shortestpath(str,x,y));
	}
	public static double shortestpath(String str,int x,int y){
	    for(int i=0;i<str.length();i++){
	        char curr=str.charAt(i);
	        if(curr=='W'){
	            x--;
	        }
	        else if(curr=='N'){
	            y++;
	        }
	        else if(curr=='E'){
	            x++;
	        }
	        else{
	            y--;
	        }
	    }
	    double distance=Math.sqrt(x*x+y*y);
	    return distance;
	}
	
}
