/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
		int [][] image={{1,1,0},{1,0,1},{0,0,0}};
		invert(image);
	}
	static void invert(int [][] image){
	    int temp;
	    for(int i=0;i<image.length;i++){
	        temp=image[0][i];
	        image[0][i]=image[0][image.length-1];
	        image[0][image.length-1]=temp;
	    }
	    for(int i=0;i<image.length;i++){
	        for(int j=0;j<image.length;j++){
	            if(image[i][j]==0){
	                image[i][j]=1;
	            }
	            else{
	                image[i][j]=0;
	            }
	        }
	    }
	    for(int i=0;i<image.length;i++){
	        for(int j=0;j<image.length;j++){
	            System.out.print(image[i][j]+" ");
	        }
	    }
	}
}
