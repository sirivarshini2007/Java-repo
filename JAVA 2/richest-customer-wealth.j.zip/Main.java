/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.stream.IntStream;
public class Main
{
	public static void main(String[] args) {
		int [][] nums={{1,5},{7,3},{3,5}};
		richest(nums);
	}
	static void richest(int [][] nums){
	    int maxi=0;
	    for(int i=0;i<nums.length;i++){
	        int result=IntStream.of(nums[i]).sum();
	        maxi=Math.max(result,maxi);
	    }
	    System.out.print(maxi);
	}
}
