/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.ArrayList;
public class Main
{
	public static void main(String[] args) {
		int [] num={0,1,2,3,4};
		int [] index={0,1,2,2,1};
		ArrayList<Integer>target=new ArrayList<>();
		result(num,index,target);
	}
	static void result(int [] num,int [] index,ArrayList<Integer>target){
	    for (int i=0;i<num.length;i++){
	        target.add(index[i],num[i]);
	    }
	    System.out.print(target);
	}
}
