/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main{
    public static void main(String [] args){
        int [][]arr={{3,7,8},{9,11,13},{15,16,17}};
        luckynumber(arr);
    }
    static void luckynumber(int [][] arr){
        for(int i=0;i<arr.length;i++){
            int smallcolindex=0;
            int small=arr[i][0];
            for(int j=1;j<arr[i].length;j++){
                if(arr[i][j]<small){
                    small=arr[i][j];
                    smallcolindex=j;
                }
            }
            boolean islucky=true;
            for(int k=0;k<arr.length;k++){
                if(arr[k][smallcolindex]>small){
                    islucky=false;
                    break;
                }
            }
            if(islucky){
                System.out.print(small);
            }
        }
    }
}