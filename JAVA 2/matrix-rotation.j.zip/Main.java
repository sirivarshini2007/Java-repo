/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
		int [][] mat={{0,1},{1,0}};
		int [][] target={{1,0},{0,1}};
		StringBuilder isEqual = new StringBuilder("true");
		check(mat,target,isEqual);
	}
	static void check(int [][] mat,int [][] target,StringBuilder isEqual){
	    while(mat.length>0){
	        for(int i=0;i<mat.length;i++){
	            for(int j=0;j<mat.length;j++){
	                int temp=mat[i][j];
	                mat[i][j]=mat[j][i];
	                mat[j][i]=temp;
	            }
	        }
	        for(int i=0;i<mat.length;i++){
	            for(int j=0;j<mat.length;j++){
	                int temp=mat[i][j];
	                mat[i][j]=mat[mat.length-j-1][i];
	                mat[mat.length-j-1][i]=temp;
	            }
	        }
	        for(int i=0;i<mat.length;i++){
	            for(int j=0;j<mat.length;j++){
	                if(mat[i][j]!=target[i][j]){
	                    isEqual.replace(0,isEqual.length(),"false");
	                }
	            }
	        }
	        isEqual.replace(0,isEqual.length(),"true");
	        
	        
	        System.out.print(isEqual);
	        
	    }
	}
}
