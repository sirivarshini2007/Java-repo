/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/

public class Main
{
	public static void main(String[] args) {
		int [] arr={20,12,10,15,2};
		sort(arr);
		for(Integer i:arr){
		    System.out.print(i+" ");
		}
	}
	static void sort(int [] arr){
	    for(int i=0;i<arr.length;i++){
	        int miniindex=i;
	        for(int j=i;j<arr.length;j++){
	            if(arr[j]<arr[miniindex]){
	                miniindex=j;
	            }
	        }
	        int temp=arr[i];
	        arr[i]=arr[miniindex];
	        arr[miniindex]=temp;
	    }
	}
}