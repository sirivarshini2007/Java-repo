/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;
public class Main
{
    public static void main(String[] args)
    {
      Scanner sv=new Scanner(System.in);
      System.out.println("Enter your age:");
      int a=sv.nextInt();
      voting_eligibility(a);
    }
    static void voting_eligibility(int a)
    {
        if (a>=18)
        {
            System.out.println("You are eligible to vote");
        }
        else
        {
            System.out.println("Not eligible to vote");
        }
    }
}