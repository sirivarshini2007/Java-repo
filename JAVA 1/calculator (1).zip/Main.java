/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/

import java.util.Scanner;
public class Main{
    public static void main(String[] args){
        Scanner sv=new Scanner(System.in);
        System.out.println("Enter the total power consumed and time duration in hours");
        int a=sv.nextInt();
        int b=sv.nextInt();
        int electricity_cost=a*b;
        System.out.println("Enter tariff rate per unit:");
        int c=sv.nextInt();
        int d=electricity_cost*c;
        System.out.println(d);
    }
}