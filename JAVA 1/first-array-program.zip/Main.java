/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;
public class Main
{
    public static void main(String[]args)
    {
        Scanner sv = new Scanner(System.in);
        int [] numbers= new int[10];
        System.out.println("Enter ten numbers:");
        for (int i=0;i<numbers.length;i++)
        {
            numbers[i]=sv.nextInt();
        }
        System.out.println("You entered:");
        for (int i=0;i<numbers.length;i++)
        {
            System.out.print(numbers[i]+" ");
        }
    }
}