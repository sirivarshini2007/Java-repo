/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;
public class Main
{
    public static void main(String[] args)
    {
      Scanner sv=new Scanner(System.in);
      System.out.println("Enter your number:");
      int a=sv.nextInt();
      int rev=0;
      palindrome(a);
    }
    static void palindrome(int a)
    {
        int rev=0;
        int temp=a;;
        while (a>0)
        {
            rev=rev*10+a%10;
            a=a/10;
            
        }
        if (temp==rev)
        {
            System.out.println("Palindrome");
        }
        else
        {
            System.out.println("Not a palindrome");
        }
        
        
        
    }
}