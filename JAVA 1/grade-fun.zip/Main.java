/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;
public class Main
{
    public static void main(String[] args)
    {
      Scanner sv=new Scanner(System.in);
      System.out.println("Enter your marks :");
      int a=sv.nextInt();
      grade(a);
    }
    static void grade(int a)
    {
       if (a>=91 && a<=100)
       {
           System.out.println("AA");
       }
       else if (a>=81 && a<=90)
       {
           System.out.println("AB");
       }
       else if (a>=71 && a<=80)
       {
           System.out.println("BB");
       }
       else if (a>=61 && a<=70)
       {
           System.out.println("BC");
       }
       else if (a>=15 && a<=60)
       {
           System.out.println("CD");
       }
       else if (a>=41 && a<=50)
       {
           System.out.println("DD");
       }
       else
       {
           System.out.println("Fail");
       }
       
        
    }
}