/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
    public static void main(String[] args)
    {
        int a=100,b=60,c=90;
        String largest=" ";
        if (a>b && a>c){
            largest="A";
        }
        else if (b>a && b>c){
            largest="B";
        }
        else if(c>a && c>b){
            largest="C";
        }
        System.out.println(largest);
    }
}