/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;
public class Main
{
    public static void main(String[] args)
    {
      Scanner sv=new Scanner(System.in);
      System.out.println("Enter your number:");
      int a=sv.nextInt();
      factorial(a);
    }
    static void factorial(int a)
    {
        int fact=1;
        while(a>0)
        {
            fact=fact*a;
            a=a-1;
        }
        System.out.println(fact);
            
        
    }
}