/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;
public class Main
{
    public static void main(String[] args)
    {
      Scanner sv=new Scanner(System.in);
      System.out.println("Enter radius:");
      int a=sv.nextInt();
      area_and_circumference(a);
    }
    static void area_and_circumference(int a)
    {
        double circumference=2*3.14*a;
        double area=3.14*a*a;
        System.out.println("Circumference :"+circumference);
        System.out.println("Area:"+area);
    }
}