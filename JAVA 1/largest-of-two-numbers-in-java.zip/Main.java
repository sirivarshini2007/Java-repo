/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import java.util.Scanner;
public class Main
{
    public static void main(String[] args)
    {
        int a,b;
        Scanner sv=new Scanner(System.in);
        System.out.println("Give values of a and b");
        a=sv.nextInt();
        b=sv.nextInt();
        if(a>b){
            System.out.println("a is greater than b");
        }
        else{
            System.out.println("b is greater than a");
        }
    }
}