/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import java.util.Scanner;
public class Main
{
    public static void main(String[] args)
    {
        int a,product=1,sum=0;
        Scanner sv= new Scanner(System.in);
        System.out.println("Enter number:");
        a=sv.nextInt();
        while (a!=0){
            product*=a%10;
            sum+=a%10;
            a=a/10;
        }
        System.out.println("Diff between the sum and product:"+(product-sum));
        
    }
}