/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;
public class Main
{
    public static void main(String[] args)
    {
      Scanner sv=new Scanner(System.in);
      System.out.println("Enter the number");
      int a=sv.nextInt();
      sum_of_natural_numbers(a);
    }
    static void sum_of_natural_numbers(int a)
    {
        int sum=0;
        while (a>0)
        {
            sum=sum+a;
            a=a-1;
        }
        System.out.println("SUM :"+sum);
    }
}