/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;
public class Main
{
    public static void main (String [] args)
    {
        int a;
        Scanner sv=new Scanner(System.in);
        System.out.println("Give your annual income");
        a=sv.nextInt();
        if (a<=50000){
            System.out.println("No tax");
        }
        else if(a<=100000){
            System.out.println("Tax:"+a*0.1);
        }
        else{
            System.out.println("Tax:"+a*0.2);
        }
        
    }
}