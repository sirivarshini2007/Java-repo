package LAB2;

import java.util.Scanner;

public class Q10 {
	public static void main(String[] args) {
		Scanner sv=new Scanner(System.in);
		System.out.println("Enter a number");
		int a=sv.nextInt();
		Q10 n=new Q10();
		int res=n.fac(a);
		System.out.print("The factorial of number "+a+" is: "+res);
	}
	int fac(int a) {
		int fact=1;
		while(a>0) {
			fact=fact*a;
			a=a-1;
		}
		return fact;
	}
}
