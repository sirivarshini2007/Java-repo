package LAB2;

import java.util.Scanner;

public class Q8 {
	public static void main(String [] args) {
		Scanner sv=new Scanner(System.in);
		System.out.println("Enter your height and weight:");
		double a=sv.nextDouble();// height in meters//
		double b=sv.nextDouble();// weight in kg//
		Q8 n=new Q8();
		String res=n.bm(a,b);
		System.out.print("You are :"+res);
	}
	String bm(double a,double b) {
		double bmi=b/(a*a);
		if (bmi>18.5) {
			return "overweight";
		}
		else if(bmi<18.5) {
			return "underweight";
		}
		else {
			return "overweight";
		}
	}
}
