package LAB2;

import java.util.Scanner;
public class Q2 {
	public static void main(String[] args) {
		Scanner sv=new Scanner(System.in);
		System.out.println("Enter a number:");
		int a=sv.nextInt();
		Q2 n=new Q2();
		int res=n.sum_even(a);
		System.out.println("The sum of the even numbers in the digit is: "+res);
		int sol=n.sum_odd(a);
		System.out.println("The sum of the odd numbers in the digit is: "+sol);
	}
	int sum_even(int a) {
		int ans_even=0;
		while(a>0) {
			int b=a%10;
			if(b%2==0) {
				ans_even=ans_even+b;
			}
			a=a/10;
		}
		return ans_even;
	}
	int sum_odd(int a) {
		int ans_odd=0;
		while(a>0) {
			int b=a%10;
			if(b%2!=0) {
				ans_odd=ans_odd+b;
			}
			a=a/10;
		}
		return ans_odd;
	}
	
}
