package LAB2;

import java.util.Scanner;
public class Q1 {
	public static void main(String[] args) {
		Scanner sv=new Scanner(System.in);
		System.out.println("Enter a number");
		int a=sv.nextInt();
		Q1 n=new Q1();
		String res=n.check(a);
		System.out.print("The number is: "+res);
	}
	String check(int a) {
		if (a>0){
			return"positive";
		}
		else if (a<0) {
			return "negative";
		}
		else {
			return "zero";
		}
	}
}
