package LAB2;

public class Q19 extends Q18 {

}
