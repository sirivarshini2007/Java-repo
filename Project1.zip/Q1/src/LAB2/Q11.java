package LAB2;

import java.util.Scanner;

public class Q11 {
	public static void main(String [] args) {
		Scanner sv=new Scanner(System.in);
		System.out.println("Enter two numbers:");
		int a=sv.nextInt();
		int b=sv.nextInt();
		Q11 n=new Q11();
		int  res=n.gcd(a,b);
		System.out.println("gcd of two numbers is:"+res);
		int sol=n.lcm(a, b, res);
		System.out.print("lcm of two numbers is:"+sol);
	}
	int gcd(int a,int b) {
		while(b!=0) {
			int tem=b;
			b=a%b;
			a=tem;
		}
		return a;
	}
	int lcm(int a,int b,int res) {
		int c=(a*b)/res;
		return c;
	}
}
