package LAB2;

import java.util.Scanner;

public class Q17 {
	public static void main(String[] args) {
		Scanner sv=new Scanner(System.in);
		System.out.println("Enter a number:");
		int a=sv.nextInt();
		Q17 n=new Q17();
		int res=n.fibo(a);
		System.out.println("The nth fibonacci number is: "+res);
	}
	int fibo(int a) {
		int b=0;
		int c=1;
		int d=b+c;
		if(a==0) {
			return b;
		}
		else if(a==1) {
			return c;
		}
		for (int i=3;i<=a;i++) {
			d=b+c;
			b=c;
			c=d;
		}
		return d;
	}
	
}
