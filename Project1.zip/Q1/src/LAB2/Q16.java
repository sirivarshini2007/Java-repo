package LAB2;

import java.util.Scanner;

public class Q16 {
	public static void main(String[] args) {
		Scanner sv=new Scanner(System.in);
		System.out.println("Enter a number:");
		int a=sv.nextInt();
		Q16 n=new Q16();
		String res=n.prime(a);
		System.out.print(res);
	}
	String prime(int a) {
		int count=0;
		for(int i=1;i<=a;i++) {
			if(a%i==0) {
				count+=1;
			}
		}
		if(count==2) {
			return "The number is prime";
		}
		else {
			return "The number is not prime";
		}
	}
}
