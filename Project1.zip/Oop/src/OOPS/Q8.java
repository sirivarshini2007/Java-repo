package OOPS;

public class Q8 {
	public static void main(String[] args) {
		Student siri=new Student(15,"SIRI",589.02f);
		siri.greeting();
	}
}
class Student{
	int rollno;
	String name;
	float marks;
	void greeting() {
		System.out.println("Hello"+name);
	}
	Student(){
		this.rollno=58;
		this.name="Siri";
		this.marks=589;
	}
	Student(int roll,String nam,float mark){
		this.rollno=roll;
		this.name=nam;
		this.marks=mark;
	}
}

