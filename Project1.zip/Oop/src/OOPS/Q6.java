package OOPS;

public class Q6 {
	static
	{
		System.out.println("Static block can be printed without the main method");
	}
}
