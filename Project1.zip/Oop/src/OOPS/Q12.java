package OOPS;

public class Q12 {
	public static void main(String[] args) {
		Student A=new Student(15,"SIRI",342);
		System.out.println(A.name);
	}
}
class Student{
	int roll;
	String name;
	int marks;
	void ECE(int rol,String nam,int mark) {
		this.roll=rol;
		this.name=nam;
		this.marks=mark;
	}
}
