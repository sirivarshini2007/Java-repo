package OOPS;

public class Q2 {
	public static void main(String[] args) {
		Student [] students=new Student[3];
		students[0]=new Student(58,"siri",65);
		students[1]=new Student(60,"vaish",75);
		students[2]=new Student(62,"maha",85);
		for(int i=0;i<3;i++) {
			students[i].display();
		}
	}
}
class Student{
	private int roll;
	private String name;
	private int marks;
	Student(int l,String m,int n){
		this.roll=roll;
		this.name=name;
		this.marks=marks;
	}
	void display() {
		System.out.println("your rollno is:"+roll);
		System.out.println("your name is:"+name);
		System.out.println("your marks are:"+marks);
	}
}
