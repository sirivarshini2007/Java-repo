package OOPS;

import java.util.Arrays;

public class Q1 {
	public static void main(String[] args) {
		Student [] students=new Student[5];
		int [] roll=new int[5];
		String [] name=new String[5];
		float [] marks=new float[5];
		Student siri =new Student();
		//siri.roll=58;
		//siri.name="SIRI";
		//System.out.println(Arrays.toString(students));
		//System.out.println(siri);
		siri.greeting();
		System.out.println(siri.roll);
		System.out.println(siri.name);
		System.out.println(siri.marks);
	}
}
class Student{
	int roll;
	String name;
	float marks;
	void greeting() {
		System.out.println("Hello my name is :"+name);
	}
	Student(){
		this.roll=13;
		this.name="Siri";
		this.marks=88.5f;
	}
}
