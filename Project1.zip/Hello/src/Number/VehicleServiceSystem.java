package Number;// VehicleServiceSystem.java

import java.util.*;

//------------------ Custom Exceptions ------------------
class InvalidVehicleTypeException extends Exception {
    public InvalidVehicleTypeException(String message) {
        super(message);
    }
}

class DuplicateBookingException extends Exception {
    public DuplicateBookingException(String message) {
        super(message);
    }
}

class BookingNotFoundException extends Exception {
    public BookingNotFoundException(String message) {
        super(message);
    }
}

//------------------ Abstract VehicleService ------------------
abstract class VehicleService {
    protected String vehicleNumber;
    protected String serviceType;
    protected double cost;
    protected int estimatedTime;
    protected String customerName;
    protected String customerContact;

    public VehicleService(String vehicleNumber, String serviceType, String customerName, String customerContact) {
        this.vehicleNumber = vehicleNumber;
        this.serviceType = serviceType;
        this.customerName = customerName;
        this.customerContact = customerContact;
        calculateCostAndTime();
    }

    public abstract void calculateCostAndTime();

    public void applyPriorityService() {
        cost *= 1.2;
        estimatedTime = Math.max(1, estimatedTime - 1);
    }

    public double getCost() {
        return cost;
    }

    public String getVehicleNumber() {
        return vehicleNumber;
    }

    public int getEstimatedTime() {
        return estimatedTime;
    }

    public String toString() {
        return vehicleNumber + " | " + getClass().getSimpleName() + " | Service: " + serviceType +
                " | Customer: " + customerName + " | Rs." + cost + " | " + estimatedTime + " hr(s)";
    }
}

//------------------ Vehicle Types ------------------
class BikeService extends VehicleService {
    public BikeService(String vehicleNumber, String serviceType, String customerName, String customerContact) {
        super(vehicleNumber, serviceType, customerName, customerContact);
    }

    public void calculateCostAndTime() {
        cost = 300;
        estimatedTime = 2;
    }
}

class CarService extends VehicleService {
    public CarService(String vehicleNumber, String serviceType, String customerName, String customerContact) {
        super(vehicleNumber, serviceType, customerName, customerContact);
    }

    public void calculateCostAndTime() {
        cost = 800;
        estimatedTime = 4;
    }
}

class TruckService extends VehicleService {
    public TruckService(String vehicleNumber, String serviceType, String customerName, String customerContact) {
        super(vehicleNumber, serviceType, customerName, customerContact);
    }

    public void calculateCostAndTime() {
        cost = 1500;
        estimatedTime = 6;
    }
}

//------------------ Booking Manager ------------------
class ServiceManager {
    private List<VehicleService> bookings = new ArrayList<>();
    private double totalIncome = 0;

    public void bookService(String vehicleType, String vehicleNumber, String serviceType,
                            String customerName, String customerContact, boolean priority)
            throws InvalidVehicleTypeException, DuplicateBookingException {

        for (VehicleService vs : bookings) {
            if (vs.getVehicleNumber().equalsIgnoreCase(vehicleNumber)) {
                throw new DuplicateBookingException("Duplicate booking for vehicle: " + vehicleNumber);
            }
        }

        VehicleService service;
        switch (vehicleType.toLowerCase()) {
            case "bike":
                service = new BikeService(vehicleNumber, serviceType, customerName, customerContact);
                break;
            case "car":
                service = new CarService(vehicleNumber, serviceType, customerName, customerContact);
                break;
            case "truck":
                service = new TruckService(vehicleNumber, serviceType, customerName, customerContact);
                break;
            default:
                throw new InvalidVehicleTypeException("Invalid vehicle type: " + vehicleType);
        }

        if (priority) {
            service.applyPriorityService();
        }

        bookings.add(service);
        totalIncome += service.getCost();
        System.out.println("Booked: " + service);
    }

    public void cancelBooking(String vehicleNumber) throws BookingNotFoundException {
        Iterator<VehicleService> iter = bookings.iterator();
        while (iter.hasNext()) {
            VehicleService vs = iter.next();
            if (vs.getVehicleNumber().equalsIgnoreCase(vehicleNumber)) {
                totalIncome -= vs.getCost();
                iter.remove();
                System.out.println("Cancelled booking for vehicle: " + vehicleNumber);
                return;
            }
        }
        throw new BookingNotFoundException("Booking not found for vehicle: " + vehicleNumber);
    }

    public void displayBookings() {
        System.out.println("\n--- Today's Bookings ---");
        for (VehicleService vs : bookings) {
            System.out.println(vs);
        }
    }

    public void displayIncome() {
        System.out.println("\nTotal Income Today: Rs." + totalIncome);
    }
}

//------------------ Main ------------------
public class VehicleServiceSystem {
    public static void main(String[] args) {
        ServiceManager manager = new ServiceManager();

        try {
            manager.bookService("Bike", "MH12AB1234", "Oil Change", "Ravi", "9876543210", false);
            manager.bookService("Car", "MH12CD5678", "Engine Check", "Priya", "9123456789", true);

            // Exception test case 1: Duplicate booking
            manager.bookService("Car", "MH12AB1234", "Wash", "Ravi", "9876543210", false);
        } catch (Exception e) {
            System.out.println("Exception: " + e.getMessage());
        }

        try {
            // Exception test case 2: Invalid vehicle type
            manager.bookService("Scooter", "MH14EF9999", "Polish", "Anil", "9988776655", false);
        } catch (Exception e) {
            System.out.println("Exception: " + e.getMessage());
        }

        try {
            // Cancel booking
            manager.cancelBooking("MH12AB1234");
        } catch (Exception e) {
            System.out.println("Exception: " + e.getMessage());
        }

        manager.displayBookings();
        manager.displayIncome();
    }
}

