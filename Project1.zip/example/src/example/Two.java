package example;
import java.util.Scanner;
public class Two {
	public static void main(String[] args) {
		Employee[] employees= new Employee[5];
		System.out.println("Enter the details:");
		Scanner sv=new Scanner(System.in);
		for(int i=0;i<5;i++) {
			System.out.println("Enter id:");
			int id=sv.nextInt();
			System.out.println("Enter name:");
			String name=sv.next();
			System.out.println("Enter role:");
			String role=sv.next();
			System.out.println("Enter salary:");
			int sal=sv.nextInt();
			employees[i]=new Employee();
			employees[i].set(id,name,role,sal);
		}
		System.out.println("1.Employee with id 102:");
		System.out.println("2.Employee with salary > 50000");
		System.out.println("Enter choice:");
		int choice=sv.nextInt();
		switch(choice) {
		case 1:
			for(Employee e:employees) {
				if(e.id==102) {
					e.display();
				}
			}
			break;
		case 2:
			for(Employee e:employees) {
				if(e.sal>50000) {
					e.display();
				}
			}
			break;
		default:
			System.out.println("Invalid choice:");

		}
	}
}
class Employee{
	int id;
	String name;
	String role;
	int sal;
	void set(int l,String m,String n,int p) {
		id=l;
		name=m;
		role=n;
		sal=p;
	}
	void display() {
		System.out.println("id:"+id+"name:"+name+"role:"+role+"salary:"+sal);
	}
}
