package example;
import java.util.Scanner;
public class One {
	public static void main(String[] args) {
		Scanner sv=new Scanner(System.in);
		Product[] obj=new Product[5];
		System.out.println("Enter the code and product name:");
		for(int i=0;i<5;i++) {
			System.out.println("Enter code:");
			int code=sv.nextInt();
			System.out.println("Enter the name of laptop:");
			String name=sv.next();
			obj[i]=new Product();
			obj[i].set(code,name);
		}
		for(int i=0;i<5;i++) {
			obj[i].display();
		}
	}
}
class Product{
	int code;
	String name;
	void set(int l,String m) {
		code=l;
		name=m;
	}
	void display() {
		System.out.println("code: "+code+"name: "+name);
	}
}
