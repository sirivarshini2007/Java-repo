package example;

import java.util.ArrayList;
import java.util.Collections;
public class Q5 {
	public static void main(String[] args) {
		ArrayList<Integer> arr=new ArrayList<Integer>();
		arr.add(10);
		arr.add(20);
		arr.add(40);
		arr.add(60);
		arr.add(18);
		Collections.sort(arr);
		for(int x:arr) {
			System.out.println(x);
		}
	}
}
