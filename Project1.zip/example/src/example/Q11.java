package example;

import java.util.Scanner;
public class Q11 {
	public static void main(String [] args) {
		Scanner sv =new Scanner(System.in);
		System.out.println("Enter a year:");
		int a=sv.nextInt();
		Q11 n=new Q11();
		boolean res=n.check(a);
		if (res) {
			System.out.println("It is a leap year");
		}
		else {
			System.out.println("It is not a leap year");
		}
	}
	boolean check(int a) {
		if(a%4==0 && (a%100!=0 || a%400==0)) {
			return true;
		}
		return false;
	}
}
