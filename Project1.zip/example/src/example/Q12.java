package example;

public class Q12 {
	public static void main(String[] args) {
		Test Q1=new Test();
		Test.display(6);
	}
}
class Test{
	static int a=1,b;
	{
		System.out.println("Instance block");
	}
	static {
		System.out.println("Hello");
	}
	static void display(int x) {
		System.out.println(x);
		System.out.println(a);
		System.out.println(b);
	}
}
