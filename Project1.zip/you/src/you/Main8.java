package you;
import java.util.Scanner;
public class Main8 {
	public static void main(String[] args) {
		Scanner sv=new Scanner(System.in);
		Trafficlight s=new Trafficlight(a,b);
		System.out.println("Enter color:");
		String a=sv.next();
		System.out.println("Enter duration:");
		int b=sv.nextInt();
		if(a.equals("red")) {
		}
		else if(a.equals("green")) {
		}
		else if(a.equals("yellow")) {
		}
		else {
			System.out.println("Invalid choice");
		}
		System.out.println("Enter next color:");
		String b=sv.next();
		s.changecolor(b);
		System.out.println("The light now is ");
	}
}
