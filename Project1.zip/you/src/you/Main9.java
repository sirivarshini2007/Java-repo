package you;

import java.util.Scanner;
public class Main9{
	public static void main(String[] args) {
		int count;
		Scanner sv=new Scanner(System.in);
		count=sv.nextInt();
		Main9 n=new Main9();
		n.sort(count);
	}
	void sort(int count) {
		String temp;
		String str[]=new String[count];
		Scanner sv2=new Scanner(System.in);
		for(int i=0;i<count;i++) {
			str[i]=sv2.nextLine();
		}
		for(int i=0;i<count;i++) {
			for(int j=i+1;j<count;j++) {
				if(str[i].compareTo(str[j])>0) {
					temp=str[i];
					str[i]=str[j];
					str[j]=temp;
				}
			}
		}
		for(int i=0;i<count;i++) {
			System.out.print(str[i]+" ");
		}
	}
}