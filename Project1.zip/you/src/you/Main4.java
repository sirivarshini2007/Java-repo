package you;
import java.util.Scanner;
public class Main4 {
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		Employee [] employees=new Employee[5];
		for(int i=0;i<5;i++) {
			System.out.println("Enter details of:"+i+1);
			System.out.println("Enter employee id:");
			int id=s.nextInt();
			System.out.println("Enter employee name:");
			String name=s.next();
			System.out.println("Enter employee job:");
			String job=s.next();
			System.out.println("Enter employee salary:");
			int sal=s.nextInt();
			employees[i]=new Employee(id,name,job,sal);
		}
		System.out.println("1.Employee with id ");
		System.out.println("2.Employee with salary");
		System.out.println("Enter your choice:");
		int choice=s.nextInt();
		switch(choice) {
		case 1:
			System.out.println("Employee id:");
			int idno=s.nextInt();
			for(Employee e:employees) {
				if(e.id==idno) {
					e.print();
				}
			}
			break;
		case 2:
			System.out.println("Employee salary:");
			int salary=s.nextInt();
			for(Employee e:employees) {
				if(e.sal>=salary) {
					e.print();
				}
			}
			break;
		default:
			System.out.println("Invalid choice");
			break;
		}
	}
}
class Employee{
	int id;
	private String name;
	private String job;
	int sal;
	public Employee(int id,String name,String job,int sal) {
		this.id=id;
		this.name=name;
		this.job=job;
		this.sal=sal;
	}
	public void print() {
		System.out.println("Employee id:"+id+" Name:"+name+" Job:"+job+" Salary:"+sal);
	}
}
