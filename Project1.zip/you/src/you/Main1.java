package you;
import java.util.Scanner;
public class Main1 {
	public static void main(String[] args) {
		Scanner sv=new Scanner(System.in);
		Rectangle[] rect=new Rectangle[2];
		System.out.println("Enter l1 and b1:");
		int l1=sv.nextInt();
		int b1=sv.nextInt();
		System.out.println("Enter l2 and b2:");
		int l2=sv.nextInt();
		int b2=sv.nextInt();
		rect[0]=new Rectangle(l1,b1);
		rect[1]=new Rectangle(l2,b2);
		System.out.println("Area of rectangles are:");
		for(int i=0;i<2;i++) {
			System.out.println(rect[i].getArea());
		}
	}
}
class Rectangle{
	private int length;
	private int breadth;
	public Rectangle(int l,int b) {
		length=l;
		breadth=b;
	}
	public int getArea() {
		return length*breadth;
	}
}
