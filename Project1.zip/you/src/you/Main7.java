package you;
import java.util.Scanner;
public class Main7 {
	public static void main(String[] args) {
		int bill=0;
		Scanner s=new Scanner(System.in);
		Product obj=new Product(bill);
		System.out.println("Enter the count you want to choose:");
		int count=s.nextInt();
		for (int i=0;i<count;i++) {
			System.out.println("Items available:");
			System.out.println("1.Food");
			System.out.println("2.Clothes");
			System.out.println("3.Stationary");
			System.out.println("Enter particular field:");
			int c=s.nextInt();
			switch(c) {
			case 1:
				obj.display1();
				System.out.println("Enter the item:");
				String item=s.next();
				if (item.equals("waffy")) {
					bill+=100;
				}
				else if(item.equals("apple")) {
					bill+=200;
				}
				else {
					bill+=150;
				}
				obj.set(bill);
				break;
			case 2:
				obj.display2();
				System.out.println("Enter the item:");
				String item1=s.next();
				if (item1.equals("tshirt")) {
					bill+=100;
				}
				else if(item1.equals("nightware")) {
					bill+=200;
				}
				else {
					bill+=150;
				}
				obj.set(bill);
				break;
			case 3:
				obj.display3();
				System.out.println("Enter the item:");
				String item2=s.next();
				if (item2.equals("pens")) {
					bill+=100;
				}
				else if(item2.equals("whitenotes")) {
					bill+=200;
				}
				else {
					bill+=150;
				}
				obj.set(bill);
				break;
			default:
				System.out.println("Invalid choice");
			}
		}
		System.out.println("Total cost is:"+obj.bill());
	}
}
class Product{
	private int totalbill;
	public Product(int totalbill) {
		this.totalbill=totalbill;
	}
	public void display1() {
		System.out.println("1.Waffy price:100");
		System.out.println("2.Apples price:200");
		System.out.println("3.Banana price:150");
	}
	public void display2() {
		System.out.println("1.T-shirt price:100");
		System.out.println("2.Night ware price:200");
		System.out.println("3.kurtas price:150");
	}
	public void display3() {
		System.out.println("1.pens price:100");
		System.out.println("2.white notes price:200");
		System.out.println("3.geometry box price:150");
	}
	public int bill() {
		return totalbill;
	}
	public void set(int l) {
		this.totalbill=l;
	}
}
