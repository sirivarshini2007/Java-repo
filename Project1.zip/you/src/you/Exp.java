package you;
import java.util.Scanner;
public class Exp{
    public static void main(String[] args){
        Scanner sv=new Scanner(System.in);
        System.out.println("Enter number of rows:");
        int a=sv.nextInt();
        int b=sv.nextInt();
        int c=sv.nextInt();
        Exp n=new Exp();
        int res=n.print(a,b);
        System.out.println("gcd of two numbers:"+res);
        System.out.println("Gcd of three numbers is:"+n.gcd(res,c));
    }
    int print(int a,int b){
    	while(b!=0) {
    		int temp=b;
    		b=a%b;
    		a=temp;
    	}
    	return a;
    }
    int gcd(int res,int c) {
    	while(c!=0) {
    		int sol=c;
    		c=res%c;
    		res=sol;
    	}
    	return res;
    }
}