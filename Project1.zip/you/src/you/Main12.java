package you;
import java.util.Scanner;
public class Main12 {
	public static void main(String [] args) {
		Scanner sv=new Scanner(System.in);
		String name="9Siri";
		System.out.print(name);
		int num = 88;
		// Trying to insert integer to character
		char ch =(char) num;
		System.out.println(ch);
	}
}
