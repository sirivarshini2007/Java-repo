package QS;

public class Q1 {
	public static void main(String[] args) {
		C o=new C();
		C.D s=o.new D();
		s.method();
	}
}
abstract class A{
	abstract class B{
		abstract void method();
	}
}
class C extends A{
	class D extends B{
		void method() {
			System.out.println("void method called");
		}
	}
}