package QS;

import java.util.Arrays;

interface Vehicle {
    void start();
    void stop();
}

abstract class Car implements Vehicle {
    // Abstract method to be implemented by subclasses
    abstract void drive();
}

class Honda extends Car {
    // Implementing the start() method from the Vehicle interface
    void start() {
        System.out.println("car starts");
    }

    // Implementing the stop() method from the Vehicle interface
    void stop() {
        System.out.println("car stops");
    }

    // Implementing the drive() method from the abstract Car class
    void drive() {
        System.out.println("car drives");
    }
}

public class IA1 {
    public static void main(String[] args) {
        Car s = new Honda();  // Create a Honda object but reference it using the Car type
        s.start();  // Calls Honda's start method
        s.stop();   // Calls Honda's stop method
        s.drive();  // Calls Honda's drive method
    }
}
