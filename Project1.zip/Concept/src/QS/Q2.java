package QS;

public class Q2 {
	public static void main(String[] args) {
		Cal s=new Cal();
		System.out.println(s.add(2,3));
		System.out.println(s.sub(4,3));
	}
}
interface A{
	int add(int a,int b);
}
interface B{
	int sub(int a,int b);
}
class Cal implements A, B{
	public int add(int a,int b) {
		return a+b;
	}
	public int sub(int a,int b) {
		return a-b;
	}
}