package Project;

import java.util.*;

class TrafficManagement {
    private Map<String, Integer> trafficData = new HashMap<>();

    public TrafficManagement() {
        trafficData.put("Main Street", new Random().nextInt(100));
        trafficData.put("2nd Avenue", new Random().nextInt(100));
        trafficData.put("Highway 1", new Random().nextInt(100));
    }

    public void monitorTraffic() {
        System.out.println("\n🚦 Traffic Status:");
        for (Map.Entry<String, Integer> entry : trafficData.entrySet()) {
            System.out.println(entry.getKey() + " - Vehicles: " + entry.getValue());
        }
    }

    public void adjustTrafficLights() {
        System.out.println("\n🔄 Adjusting traffic lights...");
        for (String road : trafficData.keySet()) {
            if (trafficData.get(road) > 50) {
                System.out.println("⚠ High traffic on " + road + "! Increasing green light duration.");
            } else {
                System.out.println("✅ Traffic is normal on " + road + ".");
            }
        }
    }
}

class WasteManagement {
    private Map<String, Integer> wasteBins = new HashMap<>();

    public WasteManagement() {
        wasteBins.put("Downtown", new Random().nextInt(100));
        wasteBins.put("Suburb Area", new Random().nextInt(100));
        wasteBins.put("Industrial Zone", new Random().nextInt(100));
    }

    public void checkWasteLevels() {
        System.out.println("\n🗑 Waste Bin Levels:");
        for (Map.Entry<String, Integer> entry : wasteBins.entrySet()) {
            System.out.println(entry.getKey() + " - Fill Level: " + entry.getValue() + "%");
            if (entry.getValue() > 80) {
                System.out.println("⚠ Waste bin at " + entry.getKey() + " is almost full! Schedule pickup.");
            }
        }
    }
}

class EnergyManagement {
    private Map<String, Integer> energyConsumption = new HashMap<>();

    public EnergyManagement() {
        energyConsumption.put("Residential", new Random().nextInt(500));
        energyConsumption.put("Commercial", new Random().nextInt(1000));
        energyConsumption.put("Industrial", new Random().nextInt(2000));
    }

    public void monitorEnergy() {
        System.out.println("\n⚡ Energy Consumption:");
        for (Map.Entry<String, Integer> entry : energyConsumption.entrySet()) {
            System.out.println(entry.getKey() + " - Consumption: " + entry.getValue() + " kWh");
            if (entry.getValue() > 1500) {
                System.out.println("⚠ High energy usage in " + entry.getKey() + "! Suggesting optimizations.");
            }
        }
    }
}

class PublicSafety {
    private List<String> emergencyReports = new ArrayList<>();

    public void reportIncident(String incident) {
        emergencyReports.add(incident);
        System.out.println("\n🚨 Emergency reported: " + incident);
        System.out.println("📡 Notifying nearest emergency response team...");
    }

    public void viewIncidents() {
        System.out.println("\n🛑 Reported Emergencies:");
        if (emergencyReports.isEmpty()) {
            System.out.println("✅ No active emergencies.");
        } else {
            for (String incident : emergencyReports) {
                System.out.println("⚠ " + incident);
            }
        }
    }
}

class SmartCityDashboard {
    private TrafficManagement traffic = new TrafficManagement();
    private WasteManagement waste = new WasteManagement();
    private EnergyManagement energy = new EnergyManagement();
    private PublicSafety safety = new PublicSafety();
    private Scanner scanner = new Scanner(System.in);

    public void startDashboard() {
        while (true) {
            System.out.println("\n=== 🌆 Smart City Dashboard ===");
            System.out.println("1. Monitor Traffic");
            System.out.println("2. Adjust Traffic Lights");
            System.out.println("3. Check Waste Levels");
            System.out.println("4. Monitor Energy Consumption");
            System.out.println("5. Report Emergency");
            System.out.println("6. View Emergency Incidents");
            System.out.println("7. Exit");
            System.out.print("Choose an option: ");

            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (choice) {
                case 1:
                    traffic.monitorTraffic();
                    break;
                case 2:
                    traffic.adjustTrafficLights();
                    break;
                case 3:
                    waste.checkWasteLevels();
                    break;
                case 4:
                    energy.monitorEnergy();
                    break;
                case 5:
                    System.out.print("Enter emergency report: ");
                    String incident = scanner.nextLine();
                    safety.reportIncident(incident);
                    break;
                case 6:
                    safety.viewIncidents();
                    break;
                case 7:
                    System.out.println("📴 Exiting Smart City Dashboard...");
                    return;
                default:
                    System.out.println("❌ Invalid choice. Try again.");
            }
        }
    }
}

public class Module1 {
    public static void main(String[] args) {
    	String url="jdbc:mysql://localhost:3306/";
        SmartCityDashboard dashboard = new SmartCityDashboard();
        dashboard.startDashboard();
    }
        }