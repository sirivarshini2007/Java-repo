package Code;
import java.util.*;

class TrafficManagement {
    private String[] roads = {
        "Main Street", "2nd Avenue", "Highway 1", "Broadway", "Maple Avenue",
        "Expressway 5", "Elm Street", "Sunset Drive", "Market Street", "Tech Park Road",
        "School Street", "Medical Avenue"
    };
    private int[] vehicleCounts = new int[roads.length];
    private Scanner scanner = new Scanner(System.in);

    public TrafficManagement() {
        Random rand = new Random();
        for (int i = 0; i < roads.length; i++) {
            vehicleCounts[i] = rand.nextInt(100);
        }
    }

    public void monitorTraffic() {
        System.out.println("\n📋 Enter the road name to check traffic:");
        String inputRoad = scanner.nextLine().trim();  // User input as string
        boolean found = false;

        for (int i = 0; i < roads.length; i++) {
            if (roads[i].equalsIgnoreCase(inputRoad)) {
                System.out.println("🚦 " + roads[i] + " - Vehicles: " + vehicleCounts[i]);
                found = true;
                break;
            }
        }

        if (!found) {
            System.out.println("❌ Road not found. Please check the spelling and try again.");
        }
    }

    public void adjustTrafficLights() {
        System.out.println("\n🛑 Enter the name of the road to adjust traffic light:");
        String inputRoad = scanner.nextLine().trim();  // User input as string
        boolean found = false;

        for (int i = 0; i < roads.length; i++) {
            if (roads[i].equalsIgnoreCase(inputRoad)) {
                System.out.println("🛣 " + roads[i] + " - Vehicles: " + vehicleCounts[i]);
                if (vehicleCounts[i] > 50) {
                    System.out.println("⚠ High traffic! Increasing green light duration.");
                } else {
                    System.out.println("✅ Traffic is normal. No change needed.");
                }
                found = true;
                break;
            }
        }

        if (!found) {
            System.out.println("❌ Road not found. Please check the spelling and try again.");
        }
    }
}

 class WasteManagement {
    private String[] locations = {"Downtown", "Suburb Area", "Industrial Zone", "Park", "Central Station"};
    private int[] fillLevels = new int[5];  // Array to store the waste levels
    private Scanner scanner = new Scanner(System.in);

    // Constructor to initialize fill levels with random values
    public WasteManagement() {
        Random rand = new Random();
        for (int i = 0; i < locations.length; i++) {
            fillLevels[i] = rand.nextInt(100); // 0 to 99
        }
    }

    // Method to check the waste levels based on user's choice
    public void checkWasteLevels() {
        // Display available locations with their respective numbers
        System.out.println("\n🗑 Select the area to check waste level:");
        for (int i = 0; i < locations.length; i++) {
            System.out.println((i + 1) + ". " + locations[i]);
        }

        // Get user input for area selection by number
        int inputChoice = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        // Validate the input and show waste level for selected area
        if (inputChoice >= 1 && inputChoice <= locations.length) {
            int index = inputChoice - 1;  // Convert number to index (0-based)
            System.out.println(locations[index] + " - Fill Level: " + fillLevels[index] + "%");
            if (fillLevels[index] > 80) {
                System.out.println("⚠ Waste bin at " + locations[index] + " is almost full! Schedule pickup.");
            } else {
                System.out.println("✅ Waste bin is within normal levels.");
            }
        } else {
            System.out.println("❌ Invalid choice. Please select a valid number from the list.");
        }
    }

    public static void main(String[] args) {
        WasteManagement wasteManagement = new WasteManagement();
        wasteManagement.checkWasteLevels();  // Test the method
    }
}
 class EnergyManagement {
	    private String[] sectors = {
	        "Residential", "Commercial", "Industrial",
	        "Street Lighting", "EV Charging Stations", "Hospitals", "Schools"
	    };
	    private int[] consumption = new int[sectors.length];

	    public EnergyManagement() {
	        Random rand = new Random();
	        for (int i = 0; i < sectors.length; i++) {
	            switch (sectors[i]) {
	                case "Residential":
	                    consumption[i] = rand.nextInt(500);
	                    break;
	                case "Commercial":
	                    consumption[i] = rand.nextInt(1000);
	                    break;
	                case "Industrial":
	                    consumption[i] = rand.nextInt(2000);
	                    break;
	                case "Street Lighting":
	                    consumption[i] = rand.nextInt(300);
	                    break;
	                case "EV Charging Stations":
	                    consumption[i] = rand.nextInt(1500);
	                    break;
	                case "Hospitals":
	                    consumption[i] = rand.nextInt(1000);
	                    break;
	                case "Schools":
	                    consumption[i] = rand.nextInt(400);
	                    break;
	            }
	        }
	    }

	    public void monitorEnergyForSector() {
	        Scanner scanner = new Scanner(System.in);

	        // Display available sectors with numbers
	        System.out.println("Select a sector to check energy consumption:");
	        for (int i = 0; i < sectors.length; i++) {
	            System.out.println((i + 1) + ". " + sectors[i]);
	        }

	        // Ask user to choose a number
	        System.out.print("Enter the number corresponding to the sector: ");
	        int choice = scanner.nextInt();

	        if (choice >= 1 && choice <= sectors.length) {
	            // Get the selected sector index
	            int index = choice - 1;
	            System.out.println("\n⚡ Energy Consumption for " + sectors[index] + ":");
	            System.out.println(sectors[index] + " - Consumption: " + consumption[index] + " kWh");

	            // Check if the consumption is high
	            if (consumption[index] > 1500) {
	                System.out.println("⚠ High energy usage in " + sectors[index] + "! Suggesting optimizations.");
	            }
	        } else {
	            System.out.println("❌ Invalid choice. Please enter a number between 1 and " + sectors.length);
	        }
	    }
	}
class PublicSafety {
    private List<String> emergencyReports = new ArrayList<>();

    public void reportIncident(String incident) {
        try {
            // Check if input is a number
            if (incident.matches(".*\\d.*")) {
                throw new IllegalArgumentException("❌ Emergency report cannot contain numbers!");
            }

            if (incident == null || incident.trim().isEmpty()) {
                System.out.println("❌ Please provide a valid emergency report (non-empty).");
                return;
            }
            emergencyReports.add(incident);
            System.out.println("\n🚨 Emergency reported: " + incident);
            System.out.println("📡 Notifying nearest emergency response team...");
        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
        }
    }

    public void viewIncidents() {
        System.out.println("\n🛑 Reported Emergencies:");
        if (emergencyReports.isEmpty()) {
            System.out.println("✅ No active emergencies.");
        } else {
            for (String incident : emergencyReports) {
                System.out.println("⚠ " + incident);
            }
        }
    }
}

class SmartCityDashboard {
    private TrafficManagement traffic = new TrafficManagement();
    private WasteManagement waste = new WasteManagement();
    private EnergyManagement energy = new EnergyManagement();
    private PublicSafety safety = new PublicSafety();
    private Scanner scanner = new Scanner(System.in);

    public void startDashboard() {
        while (true) {
            System.out.println("\n=== 🌆 Smart City Dashboard ===");
            System.out.println("1. Monitor Traffic");
            System.out.println("2. Adjust Traffic Lights");
            System.out.println("3. Check Waste Levels");
            System.out.println("4. Monitor Energy Consumption");
            System.out.println("5. Report Emergency");
            System.out.println("6. View Emergency Incidents");
            System.out.println("7. Exit");
            System.out.print("Choose an option: ");

            int choice = scanner.nextInt();
            scanner.nextLine();  // consume newline

            switch (choice) {
                case 1:
                    traffic.monitorTraffic();
                    break;
                case 2:
                    traffic.adjustTrafficLights();
                    break;
                case 3:
                    waste.checkWasteLevels();
                    break;
                case 4:
                    energy.monitorEnergyForSector();
                    break;
                case 5:
                    System.out.print("Enter emergency report (string only): ");
                    String incident = scanner.nextLine().trim();
                    safety.reportIncident(incident);
                    break;
                case 6:
                    safety.viewIncidents();
                    break;
                case 7:
                    System.out.println("📴 Exiting Smart City Dashboard...");
                    System.out.println("Thank you for using the Smart City Dashboard. Stay safe and connected! 👋");
                    return;
                default:
                    System.out.println("❌ Invalid choice. Try again.");
            }
        }
    }
}

public class Code1{
    public static void main(String[] args) {
        SmartCityDashboard dashboard = new SmartCityDashboard();
        dashboard.startDashboard();
    }
}
