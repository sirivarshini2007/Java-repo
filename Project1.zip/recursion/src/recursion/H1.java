package recursion;

import java.util.*;

// Custom Exceptions
class BookNotAvailableException extends Exception {
    public BookNotAvailableException(String msg) {
        super(msg);
    }
}

class OverdueException extends Exception {
    public OverdueException(String msg) {
        super(msg);
    }
}

class BorrowLimitExceededException extends Exception {
    public BorrowLimitExceededException(String msg) {
        super(msg);
    }
}

// Base Book class
abstract class Book {
    protected String id, title;
    protected boolean isAvailable = true;

    public Book(String id, String title) {
        this.id = id;
        this.title = title;
    }

    public boolean isAvailable() {
        return isAvailable;
    }

    public void borrow() throws BookNotAvailableException {
        if (!isAvailable)
            throw new BookNotAvailableException("Book '" + title + "' is not available.");
        isAvailable = false;
    }

    public void returnBook() {
        isAvailable = true;
    }

    public abstract String getType();
}

class ReferenceBook extends Book {
    public ReferenceBook(String id, String title) {
        super(id, title);
    }

    public String getType() {
        return "Reference Book";
    }
}

class TextBook extends Book {
    public TextBook(String id, String title) {
        super(id, title);
    }

    public String getType() {
        return "Text Book";
    }
}

class Journal extends Book {
    public Journal(String id, String title) {
        super(id, title);
    }

    public String getType() {
        return "Journal";
    }
}

// Member base class
abstract class Member {
    protected String name;
    protected int id;
    protected List<Loan> loans = new ArrayList<>();
    protected int maxBooks;

    public Member(String name, int id, int maxBooks) {
        this.name = name;
        this.id = id;
        this.maxBooks = maxBooks;
    }

    public void borrowBook(Book book) throws Exception {
        if (loans.size() >= maxBooks)
            throw new BorrowLimitExceededException("Borrow limit exceeded.");
        book.borrow();
        loans.add(new Loan(book, new Date()));
        System.out.println(name + " borrowed " + book.title);
    }

    public void returnBook(Book book) throws Exception {
        for (Loan loan : loans) {
            if (loan.getBook() == book) {
                long diff = (new Date().getTime() - loan.getDate().getTime()) / (1000 * 60 * 60 * 24);
                if (diff > 14) {
                    throw new OverdueException("Overdue! " + diff + " days late.");
                }
                book.returnBook();
                loans.remove(loan);
                System.out.println(name + " returned " + book.title);
                return;
            }
        }
        System.out.println("Loan record not found.");
    }

    public abstract String getType();
}

class Student extends Member {
    public Student(String name, int id) {
        super(name, id, 3);
    }

    public String getType() {
        return "Student";
    }
}

class Faculty extends Member {
    public Faculty(String name, int id) {
        super(name, id, 5);
    }

    public String getType() {
        return "Faculty";
    }
}

// Loan class
class Loan {
    private Book book;
    private Date date;

    public Loan(Book book, Date date) {
        this.book = book;
        this.date = date;
    }

    public Book getBook() {
        return book;
    }

    public Date getDate() {
        return date;
    }
}

// Library class
class Library {
    private List<Book> books = new ArrayList<>();
    private double fineCollected = 0.0;

    public void addBook(Book book) {
        books.add(book);
    }

    public void displayBooks() {
        for (Book b : books)
            System.out.println(b.title + " - " + b.getType() + " - " + (b.isAvailable() ? "Available" : "Not Available"));
    }

    public void collectFine(double fine) {
        fineCollected += fine;
    }

    public void displayFines() {
        System.out.println("Total fine collected today: ₹" + fineCollected);
    }
}

// Main class
public class H1 {
    public static void main(String[] args) {
        Library library = new Library();
        Scanner s = new Scanner(System.in);

        // Input Book 1 (TextBook)
        System.out.println("Enter TextBook ID:");
        String b1 = s.next();
        System.out.println("Enter TextBook Title:");
        String a1 = s.next();

        // Input Book 2 (ReferenceBook)
        System.out.println("Enter ReferenceBook ID:");
        String b2 = s.next();
        System.out.println("Enter ReferenceBook Title:");
        String a2 = s.next();

        // Input Book 3 (Journal)
        System.out.println("Enter Journal ID:");
        String b3 = s.next();
        System.out.println("Enter Journal Title:");
        String a3 = s.next();

        // Create Books
        Book c1 = new TextBook(b1, a1);
        Book c2 = new ReferenceBook(b2, a2);
        Book c3 = new Journal(b3, a3);

        // Add to Library
        library.addBook(c1);
        library.addBook(c2);
        library.addBook(c3);

        // Input members
        System.out.println("Enter Student Name:");
        String studentName = s.next();
        System.out.println("Enter Faculty Name:");
        String facultyName = s.next();

        Member s1 = new Student(studentName, 1);
        Member f1 = new Faculty(facultyName, 2);

        // Borrowing attempt
        try {
            s1.borrowBook(c1);  // Student borrows textbook
            f1.borrowBook(c1);  // Faculty tries to borrow same book (should fail)
        } catch (Exception e) {
            System.out.println("Borrowing error: " + e.getMessage());
        }

        // Return attempt
        try {
            Thread.sleep(1000); // simulate 1 second delay
            s1.returnBook(c1); // Return on time
        } catch (OverdueException oe) {
            System.out.println(oe.getMessage());
            library.collectFine(50);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        // Final status
        library.displayBooks();
        library.displayFines();
    }
}
