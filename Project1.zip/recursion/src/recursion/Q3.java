package recursion;
import java.util.Scanner;
public class Q3 {
	public static void main(String [] args) {
		Scanner s=new Scanner(System.in);
		String input=s.next();
		String res=firstupper(input);
		System.out.println("first upper case letter"+res);
	}
static String firstupper(String input) {
	for(int i=0;i<input.length();i++) {
		if(Character.isUpperCase(input.charAt(i))) {
			return String.valueOf(input.charAt(i));
		}
	}
	return "notfound";
}
}
