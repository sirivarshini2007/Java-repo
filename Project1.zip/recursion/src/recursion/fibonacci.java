package recursion;

import java.util.Scanner;
public class fibonacci {
	public static void main(String [] args) {
		System.out.println("Enter the number :");
		Scanner sv=new Scanner(System.in);
		int n=sv.nextInt();
		//System.out.print("0 1"+" ");//
		fibonacci s=new fibonacci();
		int a=0;
		int b=1;
		int res=s.fib(n, a, b);
		System.out.print(res);
	}
	int fib(int n,int a,int b) {
		int c=a+b;
		fib(n-1,b,c);
		if (n==3){
			return a+b;
		}
		return a;
	}
}
