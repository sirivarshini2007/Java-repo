package recursion;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.*;

// ------------------- Book Classes -------------------
abstract class Book {
    private String isbn;
    private String title;
    private boolean available = true;

    public Book(String isbn, String title) {
        this.isbn = isbn;
        this.title = title;
    }

    public String getIsbn() { return isbn; }
    public String getTitle() { return title; }
    public boolean isAvailable() { return available; }
    public void setAvailable(boolean available) { this.available = available; }

    @Override
    public String toString() {
        return String.format("%s [%s] %s", getClass().getSimpleName(), isbn, title);
    }
}

class ReferenceBook extends Book {
    public ReferenceBook(String isbn, String title) {
        super(isbn, title);
    }
}

class TextBook extends Book {
    public TextBook(String isbn, String title) {
        super(isbn, title);
    }
}

class Journal extends Book {
    public Journal(String isbn, String title) {
        super(isbn, title);
    }
}

// ------------------- Member Classes -------------------
abstract class Member {
    private String memberId;
    private String name;
    private List<LoanRecord> loans = new ArrayList<>();

    public Member(String memberId, String name) {
        this.memberId = memberId;
        this.name = name;
    }

    public String getMemberId() { return memberId; }
    public String getName() { return name; }
    public List<LoanRecord> getLoans() { return loans; }

    public void borrow(Book book, Library library) throws BorrowLimitExceededException {
        if (loans.size() >= getMaxLoans()) {
            throw new BorrowLimitExceededException(name + " has reached their borrow limit of " + getMaxLoans());
        }
        library.issueLoan(this, book);
    }

    public void returnBook(String isbn, Library library) throws OverdueException {
        LoanRecord toReturn = null;
        for (LoanRecord lr : loans) {
            if (lr.getBook().getIsbn().equals(isbn)) {
                toReturn = lr;
                break;
            }
        }
        if (toReturn == null) {
            System.out.println("No such loan found for ISBN: " + isbn);
            return;
        }
        library.processReturn(toReturn);
        loans.remove(toReturn);
    }

    public void addLoan(LoanRecord loan) {
        loans.add(loan);
    }

    protected abstract int getMaxLoans();
}

class StudentMember extends Member {
    private static final int MAX_LOANS = 3;

    public StudentMember(String memberId, String name) {
        super(memberId, name);
    }

    protected int getMaxLoans() {
        return MAX_LOANS;
    }
}

class FacultyMember extends Member {
    private static final int MAX_LOANS = 5;

    public FacultyMember(String memberId, String name) {
        super(memberId, name);
    }

    protected int getMaxLoans() {
        return MAX_LOANS;
    }
}

// ------------------- Loan Record -------------------
class LoanRecord {
    private Member member;
    private Book book;
    private LocalDate issueDate;
    private LocalDate dueDate;
    public static final int LOAN_PERIOD_DAYS = 14;

    public LoanRecord(Member member, Book book) {
        this.member = member;
        this.book = book;
        this.issueDate = LocalDate.now();
        this.dueDate = issueDate.plusDays(LOAN_PERIOD_DAYS);
    }

    public Member getMember() { return member; }
    public Book getBook() { return book; }
    public LocalDate getIssueDate() { return issueDate; }
    public LocalDate getDueDate() { return dueDate; }

    public long daysOverdue() {
        return LocalDate.now().isAfter(dueDate)
            ? ChronoUnit.DAYS.between(dueDate, LocalDate.now())
            : 0;
    }

    public void setIssueDate(LocalDate date) {
        this.issueDate = date;
        this.dueDate = date.plusDays(LOAN_PERIOD_DAYS);
    }

    @Override
    public String toString() {
        return member.getName() + " borrowed '" + book.getTitle() + "' on " + issueDate + ", due " + dueDate;
    }
}

// ------------------- Exceptions -------------------
class OverdueException extends Exception {
    public OverdueException(String message) {
        super(message);
    }
}

class BorrowLimitExceededException extends Exception {
    public BorrowLimitExceededException(String message) {
        super(message);
    }
}

// ------------------- Library -------------------
class Library {
    private List<Book> catalog = new ArrayList<>();
    private List<LoanRecord> activeLoans = new ArrayList<>();
    private double finesCollectedToday = 0.0;
    private static final double FINE_PER_DAY = 1.0;

    public void addBook(Book book) {
        catalog.add(book);
    }

    public void registerMember(Member m) {
        System.out.println("Registered member: " + m.getName());
    }

    public void issueLoan(Member member, Book book) {
        if (!book.isAvailable()) {
            System.out.println("Book not available: " + book);
            return;
        }
        book.setAvailable(false);
        LoanRecord loan = new LoanRecord(member, book);
        activeLoans.add(loan);
        member.addLoan(loan);
        System.out.println("Loan issued: " + loan);
    }

    public void processReturn(LoanRecord loan) throws OverdueException {
        long overdue = loan.daysOverdue();
        if (overdue > 0) {
            double fine = overdue * FINE_PER_DAY;
            finesCollectedToday += fine;
            throw new OverdueException("Book is " + overdue + " days overdue. Fine: $" + fine);
        } else {
            loan.getBook().setAvailable(true);
            activeLoans.remove(loan);
            System.out.println("Returned on time: " + loan.getBook().getTitle());
        }
    }

    public Book getBookByIsbn(String isbn) {
        for (Book book : catalog) {
            if (book.getIsbn().equals(isbn)) {
                return book;
            }
        }
        return null; // Not found
    }

    public void printDailyFines() {
        System.out.printf("Total fines collected today: $%.2f%n", finesCollectedToday);
    }
}

// ------------------- Main -------------------
public class LibrarySystem {
    public static void main(String[] args) {
        Library library = new Library();

        // Add books
        library.addBook(new TextBook("T001", "Java Programming"));
        library.addBook(new ReferenceBook("R001", "Oxford Encyclopedia"));
        library.addBook(new Journal("J001", "AI Monthly Journal"));

        // Register members
        Member alice = new StudentMember("S101", "Alice");
        Member bob = new FacultyMember("F202", "Bob");

        library.registerMember(alice);
        library.registerMember(bob);

        try {
            // Alice borrows and returns a book on time
            alice.borrow(library.getBookByIsbn("T001"), library);
            alice.returnBook("T001", library);

            // Bob borrows a journal and returns it late
            bob.borrow(library.getBookByIsbn("J001"), library);
            LoanRecord loan = bob.getLoans().get(0);
            loan.setIssueDate(LocalDate.now().minusDays(20)); // Simulate overdue
            bob.returnBook("J001", library);

        } catch (BorrowLimitExceededException e) {
            System.err.println("Limit error: " + e.getMessage());
        } catch (OverdueException e) {
            System.err.println("Overdue: " + e.getMessage());
        }

        library.printDailyFines();
    }
}
