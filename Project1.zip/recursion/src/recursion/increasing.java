package recursion;

import java.util.Scanner;
public class increasing {
	public static void main(String[] args) {
		Scanner sv=new Scanner(System.in);
		System.out.println("Enter start number:");
		int a=sv.nextInt();
		System.out.println("Enter end number:");
		int b=sv.nextInt();
		print(a,b);
	}
	public static void print(int a,int b) {
		if (a==b+1) {
			return;
		}
		System.out.print(a+" ");
		print(a+1,b);
		return;
	}
	
}
