package recursion;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
public class WordMaster {

    private static final List<String> WORDS = Arrays.asList("apple", "grape", "melon", "orange", "peach");
    private static String targetWord;
    private static int attempts;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        startGame();

        while (attempts < 6) {
            System.out.println("Enter your 5-letter guess:");
            String guess = scanner.nextLine().toLowerCase();

            if (guess.length() != 5) {
                System.out.println("Please enter a 5-letter word.");
                continue;
            }

            attempts++;
            String feedback = getFeedback(guess);

            System.out.println(feedback);

            if (guess.equals(targetWord)) {
                System.out.println("Congratulations! You've guessed the word!");
                break;
            } else if (attempts >= 6) {
                System.out.println("Game Over! The correct word was: " + targetWord);
            } else {
                System.out.println("Attempts left: " + (6 - attempts));
            }
        }

        scanner.close();
    }

    // Method to start the game by selecting a random word
    private static void startGame() {
        Random random = new Random();
        targetWord = WORDS.get(random.nextInt(WORDS.size()));
        attempts = 0;
        System.out.println("Welcome to Word Master! Guess the 5-letter word.");
    }

    // Method to provide feedback about the guess
    private static String getFeedback(String guess) {
        int correctPosition = 0;
        int correctLetterWrongPosition = 0;
        boolean[] targetUsed = new boolean[5];
        boolean[] guessUsed = new boolean[5];

        // First pass: Check for exact matches
        for (int i = 0; i < 5; i++) {
            if (targetWord.charAt(i) == guess.charAt(i)) {
                correctPosition++;
                targetUsed[i] = true;
                guessUsed[i] = true;
            }
        }

        // Second pass: Check for partial matches
        for (int i = 0; i < 5; i++) {
            if (!guessUsed[i]) {
                for (int j = 0; j < 5; j++) {
                    if (!targetUsed[j] && guess.charAt(i) == targetWord.charAt(j)) {
                        correctLetterWrongPosition++;
                        targetUsed[j] = true;
                        break;
                    }
                }
            }
        }

        return correctPosition + " correct letter(s) in the right position, " +
               correctLetterWrongPosition + " correct letter(s) in the wrong position.";
    }
}
