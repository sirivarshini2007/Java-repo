package recursion;

public class Q32 {
	public static void main(String [] args) {
		Vehicle s=new Bike("honda",50000,50);
		Vehicle p=new Car("ford",70000,60);
		((Car)p).insurance();
		((Bike)s).deposit();
		Rentable q=new Car("ford",70000,60);
		Rentable t=new Bike("honda",50000,50);
		q.calculaterent(5);
		t.calculaterent(6);
	}
}
abstract class Vehicle{
	String model;
	int rent;
	Vehicle(String model,int rent){
		this.model=model;
		this.rent=rent;
	}
}
interface Rentable{
	public int calculaterent(int days);
}
class Car extends Vehicle implements Rentable{
	int time=6;
	int inus;
	Car(String model,int rent,int inus){
		super(model,rent);
		this.inus=inus;
	}
	int insurance() {
		return (rent*time)+inus;
	}
	public int calculaterent(int days) {
		return rent*days;
	}
}
class Bike extends Vehicle implements Rentable{
	int dur=5;
	int hel;
	Bike(String model,int rent,int hel){
		super(model,rent);
		this.hel=hel;
	}
	int deposit() {
		return (rent*dur)+hel;
	}
	public int calculaterent(int days) {
		return rent*days;
	}

}