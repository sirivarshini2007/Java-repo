package SVSV;

public class Siri2 {
	public static void main(String [] args) {
		B c=new B();
		c.play();
		c.work();
		c.greet();
}
}
class Gp{
	void greet() {
		System.out.println("HEllo");
	}
}
class A extends Gp{
	void play() {
		System.out.println("playing");
	}
}
class B extends A{
	void work() {
		System.out.println("working");
	}

}
