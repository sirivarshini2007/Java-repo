package SVSV;

public class I1 {
	public static void main(String[] args) {
		Book s1=new Book("siri","hello",true);
		Magazine s2=new Magazine("varsh","hi",false);
		s1.displaydetails();
		s2.displaydetails();
	}
}
abstract class Libraryitem{
	String title;
	String author;
	boolean isaval;
	Libraryitem(String title,String author,boolean isaval){
		this.title=title;
		this.author=author;
		this.isaval=isaval;
	}
	abstract void displaydetails();
	public void check() {
		if (isaval) {
			System.out.println("Available");
		}
		else {
			System.out.println("Not available");
		}
	}
}
class Book extends Libraryitem{
	Book(String title,String author,boolean isaval){
		super(title,author,isaval);
	}
	public void displaydetails() {
		System.out.println("Title:"+title+"author:"+author);
		check();
	}
}
class Magazine extends Libraryitem{
	Magazine(String title,String author,boolean isaval){
		super(title,author,isaval);
	}
	public void displaydetails() {
		System.out.println("Title:"+title+"author:"+author);
		check();
	}
}