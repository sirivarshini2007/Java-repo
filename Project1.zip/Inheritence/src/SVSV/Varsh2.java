package SVSV;

public class Varsh2 {
	public static void main(String [] args) {
		Person s=new Student();
		Person p=new Employee();
		s.work();
		p.work();
	}
}
class Person{
	void work() {
		System.out.println("work of person");
	}
}
class Student extends Person{
	void work() {
		System.out.println("Student studies");
	}
}
class Employee extends Person{
	void work() {
		System.out.println("Employee works");
	}
}

