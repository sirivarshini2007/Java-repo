/**
 * 
 */
/**
 * 
 */
module Inherit {
}