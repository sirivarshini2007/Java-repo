package SV;

import java.util.Scanner;
public class Q67 {
	public static void main(String[] args) {
		Scanner sv=new Scanner(System.in);
		System.out.println("Enter the values of a,b,c for discriminant:");
		Double a= sv.nextDouble();
		Double b=sv.nextDouble();
		Double c=sv.nextDouble();
		Q67 n=new Q67();
		Double res=n.discriminant(a,b,c);
		System.out.println("Discriminant:"+res);
		System.out.println("Enter the numbers");
		double l=sv.nextInt();
		double s=sv.nextDouble();
		double sol=n.squareroot(l,b);
		System.out.print("Squrae root"+sol);
	}
	double discriminant(double a,double b,double c) {
		double d=b*b-4*a*c;
		return d;
	}
	double squareroot(double l,double s) {
		double e=Math.sqrt((l+s)/2);
		return e;
	}
}
