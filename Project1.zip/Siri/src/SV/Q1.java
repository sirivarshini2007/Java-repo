package SV;

import java.util.Scanner;
public class Q1 {
	public static void main(String[] args) {
		Scanner sv=new Scanner(System.in);
		System.out.println("Enter value of two numbers:");
		int a=sv.nextInt();
		int b=sv.nextInt();
		Q1 ss=new Q1();
		int res=ss.add(a,b);
		System.out.println("Addition of two numbers:"+res);
		int sol=ss.sub(a,b);
		System.out.println("Subtraction of two numbers:"+sol);
		int ans=ss.mul(a,b);
		System.out.println("Multiplication of two numbers:"+ans);
		int you=ss.divi(a,b);
		System.out.println("Division of two numbers:"+you);
	}
	int add(int a,int b) {
		int c=a+b;
		return c;
	}
	int sub(int a,int b) {
		int d=a-b;
		return d;
	}
	int mul(int a,int b) {
		int e=a*b;
		return e;
	}
	int divi(int a,int b) {
		int s=a/b;
		return s;
	}
}
