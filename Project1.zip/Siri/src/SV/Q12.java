package SV;

import java.util.Scanner;
public class Q12 {
	public static void main(String[] args) {
		Scanner sv=new Scanner(System.in);
		System.out.println("Enter distance(km) and time in seconds:");
		double a=sv.nextDouble();
		double b=sv.nextDouble();
		Q12 n=new Q12();
		double res=n.speed(a,b);
		System.out.print("Speed of vehicle:"+res);
	}
	double speed(double a,double b) {
		double c=a/b;
		return c;
	}
}
