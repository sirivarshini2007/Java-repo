package SV;

import java.util.Scanner;
public class Q9 {
	public static void main(String[] args) {
		Scanner sv=new Scanner(System.in);
		System.out.println("Enter fuel cost ad journey time:");
		int fuel_cost=sv.nextInt();//per km//
		int journey_time=sv.nextInt();//in hrs//
		System.out.println("Enter speed:");
		int a=sv.nextInt();//in m/s//
		Q9 n=new Q9();
		int res=n.distance(a,journey_time);
		System.out.println("Distance between cities:"+res);
		
	}
	int distance(int a,int journey_time) {
		int c=a*journey_time;
		return c;
	}
}
