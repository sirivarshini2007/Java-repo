package SV;

import java.util.Scanner;
public class Q11 {
	public static void main(String[] args) {
		Scanner sv=new Scanner(System.in);
		System.out.println("Enter time in seconds:");
		double a=sv.nextDouble();
		Q11 n=new Q11();
		Q11 l=new Q11();
		Q11 m=new Q11();
		double res=n.hours(a);
		System.out.println("Time in hours:"+res);
		double ans=l.minutes(a);
		System.out.println("Time in minutes:"+ans);
		double sol=m.seconds(a);
		System.out.println("Time in seconds:"+sol);
	}
	double hours(double a) {
		double b=a/3600;
		return b;
	}
	double minutes(double a) {
		double c=a/60;
		return c;
	}
	double seconds(double a) {
		return a;
	}
}
